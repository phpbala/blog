<?php
session_start();
define('HTTP',"http://".$_SERVER['SERVER_NAME'].'/basamson/blog-admin/');
define('BASE_URL',"http://".$_SERVER['SERVER_NAME'].'/basamson/');
define("PER_PAGE_LIMIT", "5"); # FRONT END
define("host", "localhost");
define("user", "root");
define("password", "root");
define("database", "dev_samson");
require 'function.php';
$db = new mysqli(host,user,password,database); 
global $db;  
date_default_timezone_set("Asia/Kolkata"); 

?>