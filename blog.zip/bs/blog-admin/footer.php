<?php
$currentPage = basename($_SERVER['REQUEST_URI']);
$restricPage = array("privileges.php","category.php","users.php"); # Restricted to Normal Users
if(isset($_SESSION['user_id']) && $user->permission()->id==3){
    if(in_array($currentPage, $restricPage)){
        echo '<script>alert("Access denied!"); document.location.href="./";</script>';
    }
}
?>
</body>
    <script>
        $(document).ready(function() {
            $('select').material_select();
          }); 
     function deleteIt(){
        if(confirm('Are you sure want to delete?')){ 
            return true;
        } return false;
    }
    </script>
    
</html>