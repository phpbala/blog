<?php
include('header.php');
include '../class/user.class.php'; 
$user = new user(); $user->checkLogin();
$msg = '';
if(isset($_POST['save'])){    extract($_POST); 
    if(isset($_POST['edit']) && $_POST['edit']!=''){ $user_id = (int)$_POST['edit'];
          if($_POST['username']!='' && $_POST['email']!=''){ extract($_POST);
          $queryC = $db->query("select email from tbl_users WHERE (email='".$email."' OR username='".$username."') AND user_id!=".$user_id);
            if($queryC->num_rows>0){
                $msg = 'Sorry, This user already exist!';
            }else{
                $db->query("UPDATE tbl_users SET `firstname`='".$db->real_escape_string($firstname)."',`lastname`='".$db->real_escape_string($lastname)."',"
                        . "`username`='".$db->real_escape_string($username)."',`email`='".$db->real_escape_string($email)."',"
                        . "`user_type_id`='".$db->real_escape_string($user_type_id)."' "
                        . "WHERE user_id=".$user_id);
                header("location:users.php");
            }
          }else{
               $msg = 'Please fill out the required fields !';
        }
    }  else{
        if($_POST['username']!='' && $_POST['email']!=''){  extract($_POST); $password = md5($username.'123'); 
            $queryC = $db->query("select email from tbl_users WHERE email='".$email."' OR username='".$username."'"); 
            if($queryC->num_rows>0){
                $msg = 'Sorry, This user already exist!';
            }else{
            $db->query("insert into tbl_users (`firstname`, `lastname`, `username`, `email`, `password`, `user_type_id`) "
                    . "values('".$db->real_escape_string($firstname)."','".$db->real_escape_string($lastname)."',"
                    . "'".$db->real_escape_string($username)."','".$db->real_escape_string($email)."','".$db->real_escape_string($password)."','".$db->real_escape_string($user_type_id)."')");
            # Mail Function here
            $to = $email;
            $subject = "BA-Samson Blog";
            $message = "<b>This is test message.</b>";
            $message .= "<h1>This is headline.</h1>";

            $header = "From:info@basamson.com \r\n";
            $header .= "Cc:info@basamson.com \r\n";
            $header .= "MIME-Version: 1.0\r\n";
            $header .= "Content-type: text/html\r\n";

            $retval = mail ($to,$subject,$message,$header);
            $msg = 'New user has been created successfuly !';
            
            }
        }else{
            $msg = 'Please fill out the required fields !'; 
        }
    }
}
if(isset($_GET['edit']) && $_GET['edit']!=''){ $user_id = (int)base64_decode($_GET['edit']);
    $query = $db->query("select * from tbl_users where user_id=".$user_id);
    $edit = $query->fetch_object();
}
if(isset($_GET['trash']) && $_GET['trash']!=''){ $us_id = (int)base64_decode($_GET['trash']);
    $db->query("DELETE from tbl_users where user_id=".$us_id);
    $msg = 'User has been deleted successfuly !';
}
if(isset($_GET['deactivate']) && $_GET['deactivate']!=''){ $u_id = (int)base64_decode($_GET['deactivate']);
    $db->query("UPDATE tbl_users SET `status`='0' where user_id=".$u_id);
    $msg = 'User has been deactivated successfuly !';
}
if(isset($_GET['activate']) && $_GET['activate']!=''){ $use_id = (int)base64_decode($_GET['activate']);
    $db->query("UPDATE tbl_users SET `status`='1' where user_id=".$use_id);
    $msg = 'User has been activated successfuly !';
}
?>
<div class="container">    
    <div class="section"></div>
    <div class="row">         
     <?php include('lhs.php');?>         
        <div class="col l10">
           <div class="row">
            <h1 class="reduceFont">All Users List</h1>
            <?php if(isset($_GET['edit'])&&$_GET['edit']!=''){ ?>
            <form method="post" id="ajaxUserE" enctype="multipart/form-data">
                            <div class="">
                                <div class="input-field col s12 l12">                        
                                    <input id="fname" name="firstname" type="text" required class="validate" value="<?=(isset($edit))?$edit->firstname:'';?>" pattern="[A-Za-z\\s]*">
                                    <label for="fname">First Name <small>[ alphabets only ]</small></label>
                                </div>
                            </div>
                            <div class="">
                                <div class="input-field col s12 l12">                        
                                    <input id="lname" name="lastname" type="text" required class="validate" value="<?=(isset($edit))?$edit->lastname:'';?>" pattern="[A-Za-z\\s]*">
                                    <label for="lname">Last Name <small>[ alphabets only ]</small></label>
                                </div>
                            </div>
                            <div class="">
                                <div class="input-field col s12 l12">                        
                                    <input id="loginname" name="username" type="text" required class="validate" value="<?=(isset($edit))?$edit->username:'';?>" pattern="[A-Za-z\\s]*">
                                    <label for="loginname">Login Name <small>[ alphabets only ]</small></label>
                                </div>
                            </div>
                            <div class="">
                                <div class="input-field col s12 l12">                        
                                    <input id="lename" name="email" type="email" required class="validate" value="<?=(isset($edit))?$edit->email:'';?>">
                                    <label for="lename">Email</label>
                                </div>
                            </div>
                            <div class="">
                                <div class="input-field col s12 l12"> 
                                    <select required="" name="user_type_id">
                                        <?php 
                                        $results = $db->query("select user_type_id,user_type from tbl_user_type order by user_type_id DESC");
                                        while($result = $results->fetch_object()){ 
                                        ?>
                                        <option value="<?=$result->user_type_id;?>" <?php if(isset($edit) && $edit->user_type_id==$result->user_type_id){ echo 'selected="selected"'; }?>><?=$result->user_type;?></option>
                                        <?php }?>
                                      </select>
                                    <label>Select User Type</label>
                                    </div>                               
                            </div>
                                <input type="submit" name="save" value="Save" class="white-text btn btn-flat red"> 
                                <?php  if(isset($_GET['edit'])&&$_GET['edit']!=''){?><input type="hidden" name="edit" value="<?=$user_id?>">
                                <input type="button" name="back" onclick="document.location.href='users.php';" value="Back" class="btn waves-effect waves-teal"><?php }?>
            </form><?php }else{?>
            <a class="waves-effect waves-light btn modal-trigger right" href="javascript:;" onclick="$('#modal1').openModal();" data-target="#modal1">Add New User</a>
            <?php } echo $msg;?> 
            <?php if(!isset($_GET['edit'])){ ?>
            <table class="bordered">
                    <thead>
                      <tr>
                          <th data-field="email">Email <small>[Unique]</small></th>
                          <th data-field="username">Username <small>[Unique]</small></th>
                          <th data-field="user_type">User Type</th>
                          <th data-field="status">Status</th>
                          <th data-field="action">Action</th>
                      </tr>
                    </thead>
                    <tbody>
                    <?php  
                        $results = $db->query("select u.*,ut.user_type from tbl_users u left join tbl_user_type ut on ut.user_type_id=u.user_type_id WHERE u.user_type_id!=1");
                        while($result = $results->fetch_object()){
                    ?>
                      <tr>
                        <td><?=$result->email?></td>
                        <td><?=$result->username?></td>
                        <td><?=$result->user_type?></td>
                        <td><?=($result->status==1)?'Active':'In-Active'?></td>
                        <td>
                            <a href="./users.php?edit=<?php echo base64_encode($result->user_id);?>" class="blue-text"><i class="tiny material-icons">mode_edit</i></a> &nbsp;
                            <?php if($result->status==1){ ?>
                            <a href="./users.php?deactivate=<?php echo base64_encode($result->user_id);?>" class="blue-text"><i class="tiny material-icons">mode_done</i></a> &nbsp;
                            <?php }else{?>
                            <a href="./users.php?activate=<?php echo base64_encode($result->user_id);?>" class="blue-text"><i class="tiny material-icons">mode_error</i></a> &nbsp;
                            <?php }?>
                        <?php if($user->permission()->id==1){ ?><a onclick="return deleteIt();" href="./users.php?trash=<?php echo base64_encode($result->user_id);?>" class="blue-text">
                        <i class="tiny material-icons">mode_delete</i></a><?php }?>
                        </td>
                      </tr>
                        <?php }?>
                    </tbody>
             </table>
            <?php }?>
            </div>
        </div>
        
        
    </div>
</div>      

<div id="modal1" class="modal"> 
    <div class="modal-content">
      <h5>New User</h5>
      <form method="post" id="ajaxUser" enctype="multipart/form-data">
                            <div class="">
                                <div class="input-field col s12 l12">                        
                                    <input id="fname1" name="firstname" type="text" required class="validate" value="" pattern="[A-Za-z\\s]*">
                                    <label for="fname1">First Name <small>[ alphabets only ]</small></label>
                                </div>
                            </div>
                            <div class="">
                                <div class="input-field col s12 l12">                        
                                    <input id="lname1" name="lastname" type="text" required class="validate" value="" pattern="[A-Za-z\\s]*">
                                    <label for="lname1">Last Name <small>[ alphabets only ]</small></label>
                                </div>
                            </div>
                            <div class="">
                                <div class="input-field col s12 l12">                        
                                    <input id="loginname1" name="username" type="text" pattern="[A-Za-z\\s]*" required class="validate" value="">
                                    <label for="loginname1">Login Name <small>[ alphabets only ]</small></label>
                                </div>
                            </div>
                            <div class="">
                                <div class="input-field col s12 l12">                        
                                    <input id="lename1" name="email" type="email" required class="validate" value="">
                                    <label for="lename1">Email</label> 
                                </div>
                            </div>
                            <div class="">
                                <div class="input-field col s12 l12"> 
                                    <select required="" name="user_type_id">
                                        <?php 
                                        $results = $db->query("select user_type_id,user_type from tbl_user_type order by user_type_id DESC");
                                        while($result = $results->fetch_object()){ 
                                        ?>
                                        <option value="<?=$result->user_type_id;?>"><?=$result->user_type;?></option>
                                        <?php }?>
                                      </select>
                                    <label>Select User Type</label>
                                    </div>                               
                            </div>
                            <input type="submit" name="save" value="Save" class="white-text btn btn-flat red">
                     </form>
    </div>
    <div class="modal-footer">
      <a href="javascript:;" class=" modal-action modal-close waves-effect waves-green btn-flat">Close</a>
    </div>
  </div>



<?php include('footer.php'); ?>


        