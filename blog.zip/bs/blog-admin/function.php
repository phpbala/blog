<?php # USER DEFINED FUNCTIONS
function clean($string) {  
   $string = str_replace(' ', '-', $string); // Replaces all spaces with hyphens.
   $string = str_replace('&', 'and', $string);
   $string = preg_replace('/[^A-Za-z0-9\-]/', '', $string); // Removes special chars.
   return preg_replace('/-+/', '-', $string);
}
function clean_old($string) {
   $string1 = str_replace(' ', '-', $string); // Replaces all spaces with hyphens.
   $string1 = str_replace('&', 'and', $string1);
   $string1 = str_replace('---', '-', $string1);
   $string1 = str_replace('--', '-', $string1);
   $return = preg_replace('/[^A-Za-z0-9\-]/', '', $string1); // Removes special chars.
   return $return;
}
function str_limit($str,$limit){
    if (strlen($str) > $limit){
        $str = substr($str, 0, $limit) . '..'; 
    }    return $str; 
}
function k_encode($str){ $b64='';
    for($i=0;$i<strlen($str);$i++){
        $b64 .= str_replace("==","$%",base64_encode($str[$i]));
    } return base64_encode($b64);
}
function k_decode($str){ $b64 =''; 
    $str = str_replace("$%","==",  base64_decode($str));
    $sp_str = str_split($str, 4);
    foreach ($sp_str as $string){
        $b64 .= base64_decode($string);
    } return $b64;
}
function ordinal($number) {
    $ends = array('th','st','nd','rd','th','th','th','th','th','th');
    if ((($number % 100) >= 11) && (($number%100) <= 13))
        return $number. 'th';
    else
        return $number. $ends[$number % 10];
}