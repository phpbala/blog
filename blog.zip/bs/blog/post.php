<?php
include_once '../header.php'; $total_post_count = ''; $offset ='';
if(isset($_GET['q']) && $_GET['q']!=''){ $title = $_GET['q'];
    $query  = $db->query("SELECT p.title,p.real_title,p.content,p.image,p.created_date,u.firstname,u.lastname,"
                         . "(SELECT GROUP_CONCAT(DISTINCT(t.tag)) from tbl_tag_link tl LEFT JOIN tbl_tags t ON t.tag_id=tl.tag_id WHERE tl.post_id=p.post_id) as tags, "
                         ." (SELECT GROUP_CONCAT(DISTINCT(t.real_tag)) from tbl_tag_link tl LEFT JOIN tbl_tags t ON t.tag_id=tl.tag_id WHERE tl.post_id=p.post_id) as real_tags "
                         . "FROM `tbl_post` p left join tbl_users u ON u.user_id=p.user_id WHERE p.status ='1' AND p.`title`='".$title."'");
    
?>
<section class="content-section">
		<div class="blog-section">
        		<div class="sub-title-header"> 
                	<h2>Blog</h2>
                    <div class="navy-years">
                    </div>
                </div>        	
   		<div class="blog-container">
          	<div class="blog-content-bx">
          	<div class="blog-content">
                <?php if($query->num_rows > 0){
                    $fp = $query->fetch_object(); $tags = explode(",", $fp->tags); $real_tag = explode(",", $fp->real_tags); ?>
            	<h2><?=$fp->real_title?></h2>
                <div class="author-date"><span class="author"><?=$fp->firstname?> <?=$fp->lastname?></span><span class="date"><?=ordinal(date('d',  strtotime($fp->created_date))).date(' M Y',  strtotime($fp->created_date))?></span></div>
                <div class="related-tags">
                <span>Related Tags :</span>
                <?php foreach($tags as $key=>$tag){ ?><a href="<?=BASE_URL?>blog/tag/<?=$tag?>" ><?=$real_tag[$key]?></a><?php }?>                    
                </div>
                <p><img src="<?=BASE_URL?>uploads/large/<?=$fp->image?>"><?=html_entity_decode($fp->content,ENT_QUOTES)?></p> 
                <?php }else{?>
                <h2>No Post Found.</h2>
                <?php }?>
                </div>
            
            </div>
            <?php include 'side-bar.php'; ?>	
          </div>
        </div>
</section> 
<?php }?>
<?php include_once '../footer.php'; ?>