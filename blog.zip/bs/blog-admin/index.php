<?php
include('header.php');
include_once '../class/msg.class.php';
include_once '../class/user.class.php';
$user = new user(); $user->logout();
echo $user->login(); 
if(!isset($_SESSION['user_id'])){ 
?>
<div class="container">    
    <div class="section"></div>
    <div class="row">
        <div class="col l12 s12">
            <form action="" method="post">
                <div class="row">
                    <div class="input-field col s12 l6 offset-l3">
                        <input id="username" name="username" type="text" required class="validate">
                      <label for="uname">User Name</label>
                    </div>
                </div>
                <div class="row">
                    <div class="input-field col s12 l6 offset-l3">
                        <input id="password" name="password" type="password" required class="validate">
                      <label for="password">Password</label>
                    </div>
                </div>
                <div class="row">
                     <div class="input-field col s12 l6 offset-l3">
                        <input type="submit" name="doLogin" value="Login" class="white-text btn btn-flat red">
                     </div>
                </div>
                     
            </form>
        </div>
    </div>
</div>
<?php }else { include('dashboard.php'); }?>

<?php include('footer.php'); ?>


        