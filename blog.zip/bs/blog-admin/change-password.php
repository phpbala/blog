<?php
include('header.php');
include '../class/user.class.php';
$user = new user(); $user->checkLogin();
$msg = '';
if(isset($_POST['save'])){    extract($_POST);
          if($_POST['password']!=''){
            if($_POST['password'] == $_POST['password1']){
                if(strlen($_POST['password'])>3){
                   $db->query("UPDATE tbl_users SET `password`='".md5($db->real_escape_string($password))."' WHERE user_id=".$_SESSION['user_id']);
                   $msg = 'Password has been updated successfuly !';
                }else{
                   $msg = 'Password should be more than 3 characters !';
                }
             }else{
                   $msg = 'Sorry, Password does not match !';
             }
          }else{
            $msg = 'Please enter the password !';  
        }
    
}
?>
<div class="container">    
    <div class="section"></div>
    <div class="row">         
     <?php include('lhs.php');?>         
        <div class="col l10">
           <div class="row">
            <h1 class="reduceFont">Change Password</h1>
            <form method="post" id="ajaxCategory" enctype="multipart/form-data">
                            <div class="row">
                                <div class="input-field col s12 l12">                        
                                    <input id="title" name="password" type="password" required class="validate" value="<?=isset($_POST['password'])?$_POST['password']:''?>">
                                    <label for="title">Enter Password</label>
                                </div>
                            </div>
                            <div class="row">
                                <div class="input-field col s12 l12">                        
                                    <input id="pw" name="password1" type="password" required class="validate" value="<?=isset($_POST['password1'])?$_POST['password1']:''?>">
                                    <input type="submit" name="save" value="Save" class="white-text btn btn-flat red"> &nbsp;<?=$msg?>
                                    <label for="pw">Re-Enter Password</label>
                                </div>
                            </div>
                     </form>
            </div>
        </div>
        
        
    </div>
</div>
       

<?php include('footer.php'); ?>


        