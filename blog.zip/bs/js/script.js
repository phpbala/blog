
$(document).ready(function() {
	 			$(window).scroll(function(){
					if ($(this).scrollTop() > 100) {
					   
						  $('.bas-header').addClass("open-nav-header");             
						
					} else {
						$('.bas-header').removeClass("open-nav-header");
					 
					  
					}
				});
		 });

$(function(){
$(".gallery-list > li").click(function(){
  $(".gallery-list > li").removeClass("active");
  $(this).addClass("active");
	var thisIndex = $(this).index();
	
  $(".gallery-content .demo-gallery").hide();
  $(".gallery-content  div.demo-gallery").eq(thisIndex).show();
});
});



$(".bio-link").click(function(e) {
	   $(".tooltip-section").show();
	   e.stopPropagation();
	
});

$(".jum-sut").click(function(e) {
	   $(".tooltip-jum-section").show();
	   e.stopPropagation();
	
});
$(".tooltip-jum-section").click(function(e){
	e.stopPropagation();
});

$(document).click(function(e){
	$(".tooltip-jum-section").hide();
});


$(".tooltip-close").click(function(){
	$(".tooltip-jum-section").hide();
});

$(".tooltip-section").click(function(e){
	e.stopPropagation();
});
$(".tooltip-close").click(function(){
	$(".tooltip-section").hide();
});


$(document).click(function(e){
	$(".tooltip-section").hide();
});





	
		 
		
