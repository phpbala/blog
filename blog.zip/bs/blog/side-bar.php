<div class="side-content">     
        <?php
            $catQuery = $db->query("select c.`category`,c.`real_category` from tbl_category c LEFT JOIN tbl_post p ON p.category_id=c.category_id WHERE p.status = '1' AND p.post_id!='' group by c.category_id"); 
            if($catQuery->num_rows > 0){
            ?>
        <ul class="categories">
                <h5 class="cat-head">CATEGORIES</h5>
            <?php 
            while($c = $catQuery->fetch_object()){
            ?><a href="<?=BASE_URL?>blog/category/<?=$c->category?>"><li><?=$c->real_category?></li></a> 
            <?php }?>
        </ul>
    <?php } 
        $postQuery = $db->query("select `title`,`real_title` from `tbl_post` WHERE `status`='1' order by `post_id` desc limit 4"); 
        if($postQuery->num_rows > 0){
        ?>
        <ul class="recnt-posts">
            <h5>RECENT POSTS</h5>
            <?php 
            while($c = $postQuery->fetch_object()){ 
            ?>
                <a href="<?=BASE_URL?>blog/post/<?=$c->title?>"><li><?=$c->real_title?></li></a>
            <?php }?>
        </ul>
    <?php } 
        $tagQuery = $db->query("select t.`tag`,t.`real_tag` from `tbl_tags` t INNER JOIN tbl_tag_link tl ON t.tag_id=tl.tag_id "
                . "INNER JOIN tbl_post p ON tl.post_id=p.post_id WHERE p.status = '1' order by t.`tag_id` desc limit 50"); 
        if($tagQuery->num_rows > 0){
        ?>
        <ul class="tags">
           <h5>TAGS</h5>
            <?php 
            while($c = $tagQuery->fetch_object()){
            ?>
            <li><a href="<?=BASE_URL?>blog/tag/<?=$c->tag?>" ><?=$c->real_tag?></a></li>
            <?php }?>                  
        </ul>
        <?php }?>
    </div>