
$(document).ready(function() {
	 			$(window).scroll(function(){
					if ($(this).scrollTop() > 100) {
					   
						  $('.bas-header').addClass("open-nav-header");             
						
					} else {
						$('.bas-header').removeClass("open-nav-header");
					 
					  
					}
				});
		 });

$(function(){
$(".gallery-list > li").click(function(){
  $(".gallery-list > li").removeClass("active");
  $(this).addClass("active");
	var thisIndex = $(this).index();
	
  $(".gallery-content .demo-gallery").hide();
  $(".gallery-content  div.demo-gallery").eq(thisIndex).show();
});
});


		
		
		 
		
