<?php header('Location:./blog/'); ?>
<h2 align="center">Welcome to BA Samson 100</h2>
<p align="center"><a href="blog/">Go To BLOG</a></p>