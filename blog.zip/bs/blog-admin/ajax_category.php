<?php
include_once 'config.php';
include '../vendor/autoload.php';
if(!isset($_SESSION['user_id'])){ echo "logout"; exit; }
# Post creation & updation 
$msg = '';
if(isset($_REQUEST['category'])){  
    
    extract($_REQUEST);
    if($_REQUEST['category']!=''){
        $q = $db->query("SELECT * from tbl_category WHERE category='".$db->real_escape_string(clean($category))."'");
        if($q->num_rows == 0){
            $db->query("insert into tbl_category (`user_id`, `category`, `real_category`) values("
                . "'".$_SESSION['user_id']."',"
                . "'".$db->real_escape_string(clean($category))."','".$db->real_escape_string($category)."')");
            $msg = '<option value="'.$db->insert_id.'">'.$category.'</option>';
        }else{
            $msg = 'exist';
        }
    }else{
            $msg = 'required';
    }

} echo $msg;

