-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Sep 08, 2016 at 01:48 PM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 5.6.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dev_samson`
--

-- --------------------------------------------------------

--
-- Table structure for table `pagination`
--

CREATE TABLE `pagination` (
  `id` int(11) NOT NULL,
  `post` varchar(250) NOT NULL,
  `postlink` varchar(250) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pagination`
--

INSERT INTO `pagination` (`id`, `post`, `postlink`) VALUES
(1, 'How to Resize text using jQuery', 'http://www.phpgang.com/?p=312'),
(2, 'How to Integrate live search in PHP and MySQL with jQuery', 'http://www.phpgang.com/?p=309'),
(3, 'How to implement jquery Timeago with php', 'http://www.phpgang.com/?p=290'),
(4, 'How to Mask an input box in jQuery', 'http://www.phpgang.com/?p=304'),
(5, 'How to block Inappropriate content with javascript validation', 'http://www.phpgang.com/?p=301'),
(6, 'How to Crop Image with jQuery and PHP', 'http://www.phpgang.com/?p=298'),
(7, 'How to Integrate jQuery Scroll Paging with PHP', 'http://www.phpgang.com/?p=294'),
(8, 'Bug Reporting with Windows Program Steps Recorder (PSR)', 'http://www.phpgang.com/?p=291'),
(9, 'How to Configure Google Cloud API in PHP', 'http://www.phpgang.com/?p=288'),
(10, 'How to convert text to MP3 Voice', 'http://www.phpgang.com/?p=284'),
(11, 'How to translate with google translate', 'http://www.phpgang.com/?p=281'),
(12, 'How to test Responsive theme in Chrome', 'http://www.phpgang.com/?p=271'),
(13, 'How to generate XML sitemap', 'http://www.phpgang.com/?p=267'),
(14, 'How to Make PHP Pagination', 'http://www.phpgang.com/?p=262'),
(15, 'How to Callback Cross Domain Data with Jquery & JSON', 'http://www.phpgang.com/?p=260'),
(16, 'PHP Server and Browser Cache', 'http://www.phpgang.com/?p=255'),
(17, 'How to Integrate Payment System with Paypal', 'http://www.phpgang.com/?p=249'),
(18, 'How to Login with Microsoft Live OAuth Connect', 'http://www.phpgang.com/?p=237'),
(19, 'How to Login with Google Account OAuth', 'http://www.phpgang.com/?p=231'),
(20, 'How to Login with Facebook Graph API in PHP', 'http://www.phpgang.com/?p=209'),
(21, 'How to Login with LinkedIn OAuth in PHP', 'http://www.phpgang.com/?p=185'),
(22, 'Twitter OAuth in PHP', 'http://www.phpgang.com/?p=175'),
(23, 'How to generate random string in PHP', 'http://www.phpgang.com/?p=170'),
(24, 'Create a Simple Forum in PHP', 'http://www.phpgang.com/?p=158'),
(25, 'Dialog of Facebook Style with CSS', 'http://www.phpgang.com/?p=150'),
(26, 'Add text to images with PHP', 'http://www.phpgang.com/?p=139'),
(27, 'Create Stream of CSV in PHP', 'http://www.phpgang.com/?p=129'),
(28, 'PHP Tutorial Urdu - 12 - Errors Reporting', 'http://www.phpgang.com/?p=120'),
(29, 'PHP Tutorial Urdu - 11 - Comments', 'http://www.phpgang.com/?p=119'),
(30, 'Force to download a file in PHP', 'http://www.phpgang.com/?p=112'),
(31, 'Send Email with SMTP and PHP Mailer', 'http://www.phpgang.com/?p=105'),
(32, 'PHP Tutorial Urdu - 10 - Embedding PHP Inside HTML', 'http://www.phpgang.com/?p=97'),
(33, 'PHP Tutorial Urdu - 9 - Output HTML Using echo or print', 'http://www.phpgang.com/?p=96'),
(34, 'PHP Tutorial Urdu - 8 - Indentation', 'http://www.phpgang.com/?p=94'),
(35, 'PHP Tutorial Urdu - 7 - Print', 'http://www.phpgang.com/?p=88'),
(36, 'PHP Tutorial Urdu - 6 - Echo', 'http://www.phpgang.com/?p=89'),
(37, 'PHP Tutorial Urdu - 5 - The phpinfo and phpInfo functions', 'http://www.phpgang.com/?p=85'),
(38, 'HTTP POST Using PHP cURL', 'http://www.phpgang.com/?p=82'),
(39, 'Submit a form without page refresh PHP & jQuery', 'http://www.phpgang.com/?p=77'),
(40, 'PHP Tutorial Urdu - 4 - Creating Your First PHP File', 'http://www.phpgang.com/?p=61'),
(41, 'PHP Tutorial Urdu - 3 - Installing XAMPP and Checking service', 'http://www.phpgang.com/?p=54'),
(42, 'PHP Tutorial Urdu - 2 - Installing XAMPP', 'http://www.phpgang.com/?p=51'),
(43, 'PHP Tutorial Urdu - 1 - What is PHP', 'http://www.phpgang.com/?p=48'),
(44, 'Create a web service with PHP', 'http://www.phpgang.com/?p=43'),
(45, 'File uploading with PHP', 'http://www.phpgang.com/?p=37'),
(46, 'Replace file_get_contents/fopen with cURL', 'http://www.phpgang.com/?p=30'),
(47, 'Mysql Stored Procedure in PHP', 'http://www.phpgang.com/?p=9');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_category`
--

CREATE TABLE `tbl_category` (
  `category_id` int(11) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `category` varchar(250) NOT NULL,
  `real_category` varchar(300) NOT NULL,
  `status` enum('0','1','2') NOT NULL DEFAULT '1',
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_category`
--

INSERT INTO `tbl_category` (`category_id`, `user_id`, `category`, `real_category`, `status`, `created_date`) VALUES
(16, 1, 'php-mysql', 'php-mysql', '1', '2016-08-23 11:39:06'),
(17, 1, 'mysql', 'mysql', '1', '2016-08-25 08:17:36'),
(18, 1, 'Windows', 'Windows', '1', '2016-08-25 08:38:17');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_modules`
--

CREATE TABLE `tbl_modules` (
  `module_id` int(11) NOT NULL,
  `module` varchar(300) NOT NULL,
  `status` enum('0','1') NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_modules`
--

INSERT INTO `tbl_modules` (`module_id`, `module`, `status`, `created_date`) VALUES
(1, 'post_module', '1', '2016-08-18 09:52:55'),
(2, 'category_module', '1', '2016-08-18 09:52:55');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_permission`
--

CREATE TABLE `tbl_permission` (
  `permission_id` int(11) NOT NULL,
  `permission` varchar(300) NOT NULL,
  `comments` varchar(300) NOT NULL COMMENT 'About Permission Comments'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_permission`
--

INSERT INTO `tbl_permission` (`permission_id`, `permission`, `comments`) VALUES
(1, 'read', 'We can read all those things'),
(2, 'read-write', 'We can add & update all those things'),
(3, 'all', 'We can add & Edit & delete Everything');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_post`
--

CREATE TABLE `tbl_post` (
  `post_id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `title` varchar(300) NOT NULL,
  `real_title` varchar(300) NOT NULL,
  `content` text NOT NULL,
  `category_id` int(11) NOT NULL,
  `image` varchar(300) NOT NULL,
  `status` enum('0','1','2') NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_post`
--

INSERT INTO `tbl_post` (`post_id`, `user_id`, `title`, `real_title`, `content`, `category_id`, `image`, `status`, `created_date`) VALUES
(32, 1, 'Php-Mysql-', 'Php Mysql ', '<h3>Argument Details</h3>\r\n\r\n<ul>\r\n	<li>\r\n	<p><strong>regexp</strong>&nbsp;&minus;&nbsp;<strong>A RegExp</strong>&nbsp;object. The match is replaced by the return value of parameter #2.</p>\r\n	</li>\r\n	<li>\r\n	<p><strong>substr</strong>&nbsp;&minus; A String that is to be replaced by&nbsp;<strong>newSubStr</strong>.</p>\r\n	</li>\r\n	<li>\r\n	<p><strong>newSubStr</strong>&nbsp;&minus; The String that replaces the substring received from parameter #1.</p>\r\n	</li>\r\n	<li>\r\n	<p><strong>function</strong>&nbsp;&minus; A function to be invoked to create the new substring.</p>\r\n	</li>\r\n	<li>\r\n	<p><strong>flags</strong>&nbsp;&minus; A String containing any combination of the RegExp flags:&nbsp;<strong>g</strong>&nbsp;- global match,&nbsp;<strong>i</strong>&nbsp;- ignore case,&nbsp;<strong>m</strong>&nbsp;- match over multiple lines. This parameter is only used if the first parameter is a string.</p>\r\n	</li>\r\n</ul>\r\n\r\n<h3>Return Value</h3>\r\n\r\n<h2>Connecting to MongoDB using node.js</h2>\r\n\r\n<p>Now for the fun part: In order to connect to a MongoDB-server, you need a database driver, which defaults to&nbsp;<a href="http://t.umblr.com/redirect?z=https%3A%2F%2Fgithub.com%2Fchristkv%2Fnode-mongodb-native&amp;t=YTY3NjEzNTVkY2Y3ZTczNDc0ZDRhNTMwMTUxZjhiMDIwMGZmYTA1Nyx3U2duMnp0eA%3D%3D" target="_BLANK">node-mongodb-native</a>. Fire up your command prompt again, switch to your node.js app folder and install it using npm:&nbsp;<em>npm install mongodb</em></p>\r\n\r\n<p><img alt="" src="http://www.spyderonlines.com/images/wallpapers/image/image-20.png" /></p>\r\n\r\n<p>Next, we will try and connect to the database. Copy the code below (taken from&nbsp;<a href="http://t.umblr.com/redirect?z=http%3A%2F%2Fchristkv.github.com%2Fnode-mongodb-native%2Fapi-articles%2Fnodekoarticle1.html&amp;t=NWU3ZTAyYTdmMGMzNzU2ZjI0MDUyNjg0ZmQ2ZWExZGEyOGFjNTdkMix3U2duMnp0eA%3D%3D" target="_BLANK">here</a>) into your node program. Make sure the database server is running before you run it:</p>\r\n\r\n<p>It simply returns a new changed string.</p>\r\n', 16, '1472466056Cypress 1Mb Quad SPI nvSRAM_0.jpg', '1', '2016-08-29 10:20:57');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_privilege`
--

CREATE TABLE `tbl_privilege` (
  `privilege_id` int(11) NOT NULL,
  `user_type_id` int(11) NOT NULL,
  `module_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL COMMENT '0 =Read Only 1 =Edit 2 =Add & Edit & Delete '
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_privilege`
--

INSERT INTO `tbl_privilege` (`privilege_id`, `user_type_id`, `module_id`, `permission_id`) VALUES
(5, 3, 0, 1),
(6, 1, 0, 3),
(7, 2, 0, 2);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tags`
--

CREATE TABLE `tbl_tags` (
  `tag_id` bigint(20) NOT NULL,
  `tag` varchar(300) NOT NULL,
  `real_tag` varchar(300) NOT NULL,
  `status` enum('0','1','2') NOT NULL DEFAULT '1',
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_tags`
--

INSERT INTO `tbl_tags` (`tag_id`, `tag`, `real_tag`, `status`, `created_date`) VALUES
(1, 'php', 'php', '1', '2016-08-22 12:47:58'),
(2, 'java', 'java', '1', '2016-08-22 12:47:58'),
(3, 'python', 'python', '1', '2016-08-22 12:47:58'),
(4, '.net', '.net', '1', '2016-08-22 12:47:58'),
(5, 'mysql', 'mysql', '1', '2016-08-22 12:47:58'),
(6, 'oracle', 'oracle', '1', '2016-08-22 12:47:58'),
(7, 'SQL', 'SQL', '1', '2016-08-22 12:47:58'),
(9, 'bala', 'bala', '1', '2016-08-22 12:47:58'),
(10, 'database', 'database', '1', '2016-08-22 12:47:58'),
(12, 'C#', 'C#', '1', '2016-08-22 12:47:58'),
(13, 'nodejs', 'nodejs', '1', '2016-08-22 12:47:58'),
(14, 'mongodb', 'mongodb', '1', '2016-08-22 12:47:58'),
(15, 'kutung', 'kutung', '1', '2016-08-22 12:47:58'),
(16, 'demo', 'demo', '1', '2016-08-23 04:28:10'),
(17, 'testing', 'testing', '1', '2016-08-23 04:28:10'),
(18, 'sdfdsf', 'sdfdsf', '1', '2016-08-23 07:34:58'),
(19, 'sdfsd', 'sdfsd', '1', '2016-08-23 07:34:59'),
(20, 'lava', 'lava', '1', '2016-08-24 09:14:24'),
(21, 'mobile', 'mobile', '1', '2016-08-24 09:18:10'),
(22, 'pyt', 'pyt', '1', '2016-08-25 06:20:06'),
(23, 'asd', 'asd', '1', '2016-08-25 06:25:44');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tag_link`
--

CREATE TABLE `tbl_tag_link` (
  `tag_link_id` bigint(20) NOT NULL,
  `tag_id` bigint(20) NOT NULL,
  `post_id` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_tag_link`
--

INSERT INTO `tbl_tag_link` (`tag_link_id`, `tag_id`, `post_id`) VALUES
(112, 1, 32),
(113, 5, 32);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_users`
--

CREATE TABLE `tbl_users` (
  `user_id` bigint(20) NOT NULL,
  `firstname` varchar(300) NOT NULL,
  `lastname` varchar(300) NOT NULL,
  `username` varchar(300) NOT NULL,
  `email` varchar(300) NOT NULL,
  `password` varchar(300) NOT NULL,
  `user_type_id` int(11) NOT NULL DEFAULT '3' COMMENT 'Super=1 , Admin=2, User=3',
  `status` enum('0','1') NOT NULL DEFAULT '1',
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_users`
--

INSERT INTO `tbl_users` (`user_id`, `firstname`, `lastname`, `username`, `email`, `password`, `user_type_id`, `status`, `created_date`) VALUES
(1, 'kutung', 'IT', 'kutung', 'info@kutung.com', 'eff03de71ceb1e2ae7f9a675de807573', 1, '1', '2016-08-17 09:27:02'),
(2, 'bala', 'sundar', 'bala', 'bala@kutung.com', 'c975edb70f08229bbeb298dede828331', 3, '1', '2016-08-18 09:22:26'),
(3, 'Admin', 'Admin', 'admin', 'admin@kutung.com', '0192023a7bbd73250516f069df18b500', 2, '1', '2016-08-18 09:22:49'),
(5, 'test', 'test', 'test', 'test@gmail.com', 'cc03e747a6afbbcbf8be7668acfebee5', 3, '1', '2016-08-19 09:13:04');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user_type`
--

CREATE TABLE `tbl_user_type` (
  `user_type_id` int(11) NOT NULL,
  `user_type` varchar(300) NOT NULL,
  `status` enum('0','1') NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_user_type`
--

INSERT INTO `tbl_user_type` (`user_type_id`, `user_type`, `status`, `created_date`) VALUES
(1, 'Super Admin', '1', '2016-08-18 09:16:55'),
(2, 'Moderate', '1', '2016-08-18 09:19:19'),
(3, 'Users', '1', '2016-08-18 09:19:22');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `pagination`
--
ALTER TABLE `pagination`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_category`
--
ALTER TABLE `tbl_category`
  ADD PRIMARY KEY (`category_id`),
  ADD KEY `category_name` (`category`,`status`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `real_category` (`real_category`);

--
-- Indexes for table `tbl_modules`
--
ALTER TABLE `tbl_modules`
  ADD PRIMARY KEY (`module_id`),
  ADD KEY `module` (`module`);

--
-- Indexes for table `tbl_permission`
--
ALTER TABLE `tbl_permission`
  ADD PRIMARY KEY (`permission_id`),
  ADD KEY `permision` (`permission`);

--
-- Indexes for table `tbl_post`
--
ALTER TABLE `tbl_post`
  ADD PRIMARY KEY (`post_id`),
  ADD KEY `title` (`title`,`category_id`,`image`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `category_id` (`category_id`),
  ADD KEY `real_title` (`real_title`);

--
-- Indexes for table `tbl_privilege`
--
ALTER TABLE `tbl_privilege`
  ADD PRIMARY KEY (`privilege_id`),
  ADD KEY `user_type_id` (`user_type_id`,`module_id`),
  ADD KEY `module_id` (`module_id`),
  ADD KEY `permission_id` (`permission_id`);

--
-- Indexes for table `tbl_tags`
--
ALTER TABLE `tbl_tags`
  ADD PRIMARY KEY (`tag_id`),
  ADD KEY `tag` (`tag`),
  ADD KEY `real_tag` (`real_tag`);

--
-- Indexes for table `tbl_tag_link`
--
ALTER TABLE `tbl_tag_link`
  ADD PRIMARY KEY (`tag_link_id`),
  ADD KEY `tag_id` (`tag_id`,`post_id`),
  ADD KEY `post_id` (`post_id`);

--
-- Indexes for table `tbl_users`
--
ALTER TABLE `tbl_users`
  ADD PRIMARY KEY (`user_id`),
  ADD KEY `username` (`username`,`email`,`password`),
  ADD KEY `firstname` (`firstname`,`lastname`),
  ADD KEY `user_type_id` (`user_type_id`);

--
-- Indexes for table `tbl_user_type`
--
ALTER TABLE `tbl_user_type`
  ADD PRIMARY KEY (`user_type_id`),
  ADD KEY `user_type` (`user_type`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `pagination`
--
ALTER TABLE `pagination`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;
--
-- AUTO_INCREMENT for table `tbl_category`
--
ALTER TABLE `tbl_category`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT for table `tbl_modules`
--
ALTER TABLE `tbl_modules`
  MODIFY `module_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `tbl_permission`
--
ALTER TABLE `tbl_permission`
  MODIFY `permission_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `tbl_post`
--
ALTER TABLE `tbl_post`
  MODIFY `post_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;
--
-- AUTO_INCREMENT for table `tbl_privilege`
--
ALTER TABLE `tbl_privilege`
  MODIFY `privilege_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `tbl_tags`
--
ALTER TABLE `tbl_tags`
  MODIFY `tag_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
--
-- AUTO_INCREMENT for table `tbl_tag_link`
--
ALTER TABLE `tbl_tag_link`
  MODIFY `tag_link_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=114;
--
-- AUTO_INCREMENT for table `tbl_users`
--
ALTER TABLE `tbl_users`
  MODIFY `user_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `tbl_user_type`
--
ALTER TABLE `tbl_user_type`
  MODIFY `user_type_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbl_category`
--
ALTER TABLE `tbl_category`
  ADD CONSTRAINT `tbl_category_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `tbl_users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `tbl_post`
--
ALTER TABLE `tbl_post`
  ADD CONSTRAINT `tbl_post_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `tbl_users` (`user_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `tbl_post_ibfk_2` FOREIGN KEY (`category_id`) REFERENCES `tbl_category` (`category_id`) ON DELETE CASCADE;

--
-- Constraints for table `tbl_privilege`
--
ALTER TABLE `tbl_privilege`
  ADD CONSTRAINT `tbl_privilege_ibfk_1` FOREIGN KEY (`user_type_id`) REFERENCES `tbl_user_type` (`user_type_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `tbl_privilege_ibfk_2` FOREIGN KEY (`permission_id`) REFERENCES `tbl_permission` (`permission_id`) ON DELETE CASCADE;

--
-- Constraints for table `tbl_tag_link`
--
ALTER TABLE `tbl_tag_link`
  ADD CONSTRAINT `tbl_tag_link_ibfk_1` FOREIGN KEY (`post_id`) REFERENCES `tbl_post` (`post_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `tbl_tag_link_ibfk_2` FOREIGN KEY (`tag_id`) REFERENCES `tbl_tags` (`tag_id`) ON DELETE CASCADE;

--
-- Constraints for table `tbl_users`
--
ALTER TABLE `tbl_users`
  ADD CONSTRAINT `tbl_users_ibfk_1` FOREIGN KEY (`user_type_id`) REFERENCES `tbl_user_type` (`user_type_id`) ON DELETE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
