<?php 
$msg = '';
//if(isset($_POST['save_category'])){
//        if($_POST['category']!=''){            extract($_POST);
//            $db->query("insert into tbl_category (`user_id`, `category`, `real_category`) values("
//                    . "'".$_SESSION['user_id']."',"
//                    . "'".$db->real_escape_string(clean($category))."','".$db->real_escape_string($category)."')");
//            $msg = 'New category has been created successfuly !'; 
//        }
//}
if(isset($_GET['edit']) && $_GET['edit']!=''){ $post_id = (int)base64_decode($_GET['edit']); 
    $query = $db->query("select * from tbl_post where post_id=".$post_id);
    $edit = $query->fetch_object();
    $queryTag = $db->query("select group_concat(t.`tag`) as tags from tbl_tag_link tl LEFT JOIN tbl_tags t ON tl.tag_id=t.tag_id where tl.post_id=".$post_id);
    $ft = $queryTag->fetch_object(); 
}
?>
<div class="container">    
    <div class="section"></div>
    <div class="row">
        <?php include('lhs.php'); ?>
        <div class="col l10">
            <div class="row">
                <h1 class="reduceFont blue-text">Add Post</h1>
                <!--<hr>-->
                <div class="col l12 s12">
                    <span id="ajax_op"></span>
                    <form method="post" id="ajaxPost" action="ajax_post.php" enctype="multipart/form-data">
                            <div class="row">
                                <div class="input-field col s12 l12">                        
                                    <input id="title" name="title" type="text" class="validate" value="<?=(isset($edit))?$edit->real_title:'';?>">
                                    <div class="red darken-4 req r-title" style="color: #FFF;">Please enter the title !</div>
                                  <label for="title">Enter Post Title</label>
                                </div>
                            </div>
                            <div class="row">
                                <div class="input-field col s12 l12">
                                    <label for="editor1">Post Content</label>
                                    <br />
                                    <textarea name="content" id="editor1" rows="10" cols="80">
                                        <?php echo (isset($edit))?$edit->content:'';?>
                                    </textarea>
                                    <div class="red darken-4 req r-content" style="color: #FFF;">Please enter the content !</div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="input-field col s12 l12"> 
                                    <select name="category_id" id="category_id"> 
                                        <option value="" selected>Choose your option</option>
                                        <?php 
                                        $results = $db->query("select category_id,category from tbl_category");
                                        while($result = $results->fetch_object()){ 
                                        ?>
                                        <option value="<?=$result->category_id;?>" <?=(isset($edit) && $edit->category_id==$result->category_id)?'selected="selected"':''?>><?=$result->category;?></option>
                                        <?php }?>
                                      </select>
                                    <label>Select Category</label>
                                    <a class="waves-effect modal-trigger" href="javascript:;" onclick="$('#modal1').openModal();" data-target="#modal1">Add New Category</a>
                                    <span id="op_cat"></span>
                                    <div class="red darken-4 req r-category" style="color: #FFF;">Please choose the category !</div>
                                    </div>                               
                            </div>
                            <div class="row">
                                <div class="file-field input-field col s12 l12">
                                    <div class="btn grey darken-2">
                                        <span>Upload Images</span>
                                        <input type="file" name="upload">
                                        <input type="hidden" name="MAX_FILE_SIZE" value="2048000" />
                                    </div>
                                      <div class="file-path-wrapper">
                                        <input class="file-path validate" type="text">
                                      </div>
                                    <small>Image size should be below 1MB</small>
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="input-field col s12 l12"> 
                                    <input type="text" placeholder="Tags" name="tags" id="tags" value="<?=(isset($ft))?$ft->tags:'';?>" data-role="materialtags" />
                                    <div class="red darken-4 req r-tag" style="color: #FFF;">Please enter the tags!</div>
                                </div>
                            </div>
                                                        
                            <div class="row">
                                <div class="input-field col s12 l12">
                                   <?php if(isset($post_id)&&$post_id!=''){?><input type="hidden" name="edit" value="<?=$post_id?>"><?php }?>
                                   <input type="submit" name="save" value="Save" class="white-text btn btn-flat red">
                                   <input type="submit" name="publish" value="Publish" class="white-text btn btn-flat green"> 
                                </div>
                            </div>
                     </form>
                </div>
            </div>
        </div>
        <!-- show list page sample -->
        
    </div>
</div>
<!-- Modal Structure -->
  <div id="modal1" class="modal">  
    <div class="modal-content"> 
        <h5>New Category</h5><span id="opcat"></span>
            <div class="row">
                <div class="input-field col s12 l12">                        
                    <input id="cat" name="category" type="text" required class="validate" value="">
                    <div class="req r-cat red darken-4" style="color:#FFF">Please enter the category !</div>
                    <input type="submit" name="save_category" id="submitCat" value="Save" class="white-text btn btn-flat red">
                  <label for="cat">Add New Category</label> 
                </div>
            </div>
    </div>
    <div class="modal-footer">
      <a href="javascript:;" class=" modal-action modal-close waves-effect waves-green btn-flat">Close</a>
    </div>
  </div>  
<script src="js/typeahead.bundle.js"></script> 
<script>
    var citynames = new Bloodhound({
        datumTokenizer: Bloodhound.tokenizers.obj.whitespace('name'),
        queryTokenizer: Bloodhound.tokenizers.whitespace,
        prefetch: {
            url: 'tags_list.php',
            filter: function(list) {
                return $.map(list, function(cityname){
                    return { name: cityname };
                });
            }
        }
    });

    citynames.initialize();

    $('input#tags').materialtags({
        typeaheadjs: {
            name: 'citynames',
            displayKey: 'name',
            valueKey: 'name',
            source: citynames.ttAdapter()
        }
    });
</script>
<script>
// Replace the <textarea id="editor1"> with a CKEditor
// instance, using default configuration.
CKEDITOR.replace( 'editor1' );
for(var instanceName in CKEDITOR.instances)
{
    CKEDITOR.instances[instanceName].updateElement();
}
$(document).ready(function(){
    $("#submitCat").click(function(e){ var cat = $('#cat'); 
        if(cat.val() == ''){
            $('.r-cat').show();
            cat.focus(); return false;
        }else if(cat.val().length < 3){
            $('.r-cat').show().html('Category should be above 3 characters!');
            cat.focus(); return false;
        } var catVal = cat.val();
        $.ajax({
                    url: 'ajax_category.php?category='+catVal,
                    type: 'GET',
                    contentType: false,
                    cache: false,
                    processData:false,
                    success: function(data, textStatus, jqXHR)
                    {// required 
                        //alert(data); return false; 
                            if(data == ''){
                                $('#opcat').html("Sorry, Could't add new category !");
                            }else if(data == 'required'){ var req = "Please enter the category !";
                                alert(req);
                                $('.r-cat').show().html(req);
                            }else if(data == 'exist'){ var req = "Sorry, This category is already exist!";
                                alert(req);
                                $('.r-cat').show().html(req);
                            }else{
                                $('select#category_id option:last').before(data);
                                $('select#category_id option:last').prev().prop('selected',true);
                                $('select').material_select();
                                $('.modal-close').click(); 
                                $('#op_cat').html('New category has been added successfuly !');
                            }
                    },
                    error: function(jqXHR, textStatus, errorThrown) 
                    {
                            $("#opcat").html(textStatus); 
                    }           
               });
    });
    $("#ajaxPost").submit(function(e){ var postTitle = $("#title").val();
            
            if(postTitle==''){
                $(".r-title").show().html('Please enter the title !');
                $("#title").focus(); 
                return false;
            }else if(postTitle.length < 4){ 
                $(".r-title").show().html('Title should be above 4 character !');
                $("#title").focus();
                return false;
            }
            if($('#editor1').val()==''){ $(".r-title").hide();
                $(".r-content").show(); 
                 return false;
            }
            if($('#category_id').val()==''){ $(".r-content").hide();
                $(".r-category").show();
                $("#category_id").focus();
                 return false;
            }
            if($('#tags').val()==''){ $(".r-category").hide();
                $(".r-tag").show();
                $("#tags").focus();
                 return false;
            }
            
            for (instance in CKEDITOR.instances ) {
                    CKEDITOR.instances[instance].updateElement();
                }
            var formObj = $(this);
            var formURL = formObj.attr("action");

            if(window.FormData !== undefined)  // for HTML5 browsers
            {

                var formData = new FormData(this);
                $.ajax({
                    url: formURL,
                    type: 'POST',
                    data:  formData,
                    mimeType:"multipart/form-data",
                    contentType: false,
                    cache: false,
                    processData:false,
                    success: function(data, textStatus, jqXHR)
                    {// required
                            //alert(data); return false;  
                            if(data == 'required'){ var req = "Please fill out the required fields !";
                                alert(req);
                                $("#ajax_op").html(req);
                            }else if(data == 'max_size_1M'){ var req = "Sorry, Upload image size should not be above 1 MB !";
                                alert(req);
                                $("#ajax_op").html(req);
                            }else if(data == 'error'){
                                alert(data);
                                $("#ajax_op").html(data);
                            }else if(data == 'exist'){ var exist = "Sorry, This post '"+postTitle+"' already exist !";
                                alert(exist);
                                $("#ajax_op").html(exist);
                            }else if(data == 'logout'){ alert("Sorry, Session has been expired !");
                                document.location.href = './';
                            }else{ 
                                $("#ajax_op").html(data);
                                document.location.href = 'list.php'; 
                            }
                    },
                    error: function(jqXHR, textStatus, errorThrown) 
                    {
                            $("#ajax_op").html(textStatus); 
                    }           
               });
                e.preventDefault();
                e.unbind();
           }  
        });
});
</script>  