<?php
class category{
    public function create(){
        if(isset($_POST['login'])){
            
        }
    }
    public function update(){
        
    }
    public function delete(){
        
    }
    public function status(){
        
    }
}