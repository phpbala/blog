<?php 
include_once '../header.php'; $total_post_count = ''; $offset ='0';
if(isset($_GET['tag_name']) && $_GET['tag_name']!=''){ $tag_name = $_GET['tag_name']; 

$pQuery  = $db->query("SELECT count(*) as total_post_count,t.real_tag FROM `tbl_post` p LEFT JOIN tbl_tag_link tl ON tl.post_id=p.post_id LEFT JOIN tbl_tags t ON t.tag_id=tl.tag_id  "
        . "WHERE t.tag='".$tag_name."' GROUP BY p.post_id");
$pCF     = $pQuery->fetch_object();
$total_post_count = $pCF->total_post_count; 

?>
<script type="text/javascript" src="<?=BASE_URL?>blog/js/jquery-1.8.0.min.js"></script>
<script type="text/javascript">
$(document).ready(function(){ var PageId = '0';  
    var hashId = window.location.hash.substr(1); 
    var pattern = /Page=/i;
    var PageId = hashId.replace(pattern, '');
   changePagination(PageId);	 
});
function changePagination(pageId){ 
     $(".flash").show();
     $(".flash").fadeIn(400).html
                ('Loading <img src="<?=BASE_URL?>blog/images/load.gif" />');
     var dataString = 'pageId='+pageId+'&tag_name=<?=$tag_name?>'; 
     $.ajax({
           type: "POST",
           url: "<?=BASE_URL?>blog/loadTagBlog.php",
           data: dataString,
           cache: false,
           success: function(result){ 
           $(".flash").hide();
           $("#pageData").html(result);
           }
      });
}
</script>
<section class="content-section">
		<div class="blog-section">
        		<div class="sub-title-header">
                            <h2>Blog</h2>
                <div class="navy-years">
                </div>
                </div>
        	
   		<div class="blog-container">
                <span class="flash"></span>
                <div class="tag-heading"> <span class="tag-txt">Tag: </span><span class="tags-title">Samson </span> </div>
          	<div class="blog-content-bx" id="pageData">     
                   <!-- Ajax Data loadTagBlog -->            
                </div>
            <?php include 'side-bar.php'; ?>	
          </div>
        </div>
</section> 
<?php }?>
<?php include_once '../footer.php'; ?>