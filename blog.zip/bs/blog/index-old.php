<?php 
$getBasename =  basename(getcwd());
if($getBasename == 'blog') include '../header.php'; else include 'header.php';
$setLimit = PER_PAGE_LIMIT; $offset = 0; $page =0;
$pQuery  = $db->query("SELECT count(*) as total_post_count from tbl_post WHERE `status`='1'");
$pCF     = $pQuery->fetch_object();
$total_post_count = $pCF->total_post_count;

$start=0;
$limit=1;

if(isset($_GET['id'])){
	$id=$_GET['id'];
	$start=($id-1)*$limit; 
}else{
	$id=1;
}

$nextPage = 1; $prevPage = ''; 
if(isset($_GET['page']) && $_GET['page']!=''){
    $page   = (int)$_GET['page'];
    $offset = ($page * $setLimit);
    $nextPage=$page+1;
    $prevPage=$page-1;
}else {
    $page = 1;
 }
 $checkCount = $setLimit+$offset; 
?>
<script type="text/javascript" src="js/jquery-1.8.0.min.js"></script>
<script type="text/javascript">
$(document).ready(function(){  var PageId = '0';
    var hashId = window.location.hash.substr(1);
    var pattern = /Page=/i;
    var PageId = hashId.replace(pattern, '');
    changePagination(PageId);	
});
function changePagination(pageId){
     $(".flash").show();
     $(".flash").fadeIn(400).html
                ('Loading <img src="images/load.gif" />');
     var dataString = 'pageId='+ pageId;
     $.ajax({
           type: "POST",
           url: "loadBlog.php",
           data: dataString,
           cache: false,
           success: function(result){
           $(".flash").hide();
           $("#pageData").html(result);
           }
      });
}
</script>
<section class="content-section">
		<div class="blog-section">
        		<div class="sub-title-header">
                	<h2>Blog</h2>
                    <div class="navy-years">
                    </div>
                </div>        	
   	<div class="blog-container"> 
            <span class="flash"></span>
            <div class="blog-content-bx" id="pageData">
                 <?php                  
                 #echo "DESC limit $offset,$setLimit";   
                 $query  = $db->query("SELECT p.title,p.real_title,p.content,p.image,p.created_date,u.firstname,u.lastname,"
                         . "(SELECT GROUP_CONCAT(DISTINCT(t.tag)) from tbl_tag_link tl LEFT JOIN tbl_tags t ON t.tag_id=tl.tag_id WHERE tl.post_id=p.post_id) as tags,"
                         ." (SELECT GROUP_CONCAT(DISTINCT(t.real_tag)) from tbl_tag_link tl LEFT JOIN tbl_tags t ON t.tag_id=tl.tag_id WHERE tl.post_id=p.post_id) as real_tags "
                         . "FROM `tbl_post` p left join tbl_users u ON u.user_id=p.user_id WHERE p.status ='1'  ORDER BY p.post_id DESC LIMIT $start, $limit"); 
                 
                 $i=0; if($query->num_rows > 0){
                 while($fp = $query->fetch_object()){ $tags = explode(",", $fp->tags); $real_tag = explode(",", $fp->real_tags);
                 ?>
                   <div class="blog-content <?=($i==0)?'first':'';?>">
                    <h2><?=ucfirst($fp->real_title)?></h2> 
                    <div class="author-date"><span class="author"><?=$fp->firstname?></span><span class="date"><?=ordinal(date('d',  strtotime($fp->created_date))).date(' M Y',  strtotime($fp->created_date))?></span></div>
                    <div class="related-tags">
                        <span>Related Tags :</span>
                        <?php foreach($tags as $key=>$tag){ ?><a href="<?=BASE_URL?>tag/<?=$tag?>" ><?=$real_tag[$key]?></a><?php }?>
                    </div>
                    <div class="post-list" style="padding-top:10px;">
                        <img src="<?=BASE_URL.'uploads/sm/'.$fp->image?>" width="180" class="textwrap">
                    <?php 
                    $content = $fp->content;
                    $content = preg_replace("/<img[^>]+\>/i", "", $content);
                    echo html_entity_decode(str_limit($content,475),ENT_QUOTES);?>
                    </div> <div class="clearfix"></div>
                    <a href="<?=BASE_URL?>./blog/<?=$fp->title;?>"><span class="read-mre">Read More</span></a>
                  </div>
                 <?php $i++; }?>
                    <?php
                //fetch all the data from database.
                $rows=$total_post_count;
                
                //calculate total page number for the given table in the database 
                $total=ceil($rows/$limit);
                ?>
                    <div class="pagination-section">
                        <ul class="pagination">
                            <li class="pag-first"><a href="?id=1"></a></li>
                            <?php if($id>1){
                                    //Go to previous page to show previous 10 items. If its in page 1 then it is inactive
                                    echo '<li class="pag-previous"><a href="?id='.($id-1).'"></a></li>';
                            }else{
                                    echo '<li class="class="pag-previous""><a href="javascript:;"></a></li>';
                            } ?>
                            <?php
                            for($i=1;$i<=$total;$i++)
                            {
                                    if($i==$id) { echo '<li class="active"><a href="javascript:;">'.$i.'</a></li>'; }else { echo '<li><a href="?id='.$i.'">'.$i.'</a></li>'; }
                            }?>
                            <?php if($id > 3){ ?><li><a href="#">....</a></li><?php } ?>
                            <?php if($id!=$total){
                                        ////Go to previous page to show next 10 items.
                                        echo '<li class="pag-next"><a href="?id='.($id+1).'"></a></li>';
                                }else{
                                        echo '<li class="pag-next"><a href="javascript:;"></a></li>';
                                }
                            ?>
                            <li class="pag-last"><a href="?id=<?=$total?>"></a></li>
                        </ul>
                  </div>
                 <?php }else{?>
                    <div class="blog-content">
                        <h2>No Posts Found.</h2>
                    </div>
                 <?php }?>
            </div>
            
            <?php include 'side-bar.php'; ?>
          </div>
        </div>
</section> 
<style>
div.pagination {
padding: 3px;
margin: 3px;
text-align:center;
}

div.pagination a {
padding: 2px 5px 2px 5px;
margin: 2px;
border: 1px solid #AAAADD;

text-decoration: none; /* no underline */
color: #000099;
}
div.pagination a:hover, div.digg a:active {
border: 1px solid #000099;

color: #000;
}
div.pagination span.current {
padding: 2px 5px 2px 5px;
margin: 2px;
border: 1px solid #000099;

font-weight: bold;
background-color: #000099;
color: #FFF;
}
div.pagination span.disabled {
padding: 2px 5px 2px 5px;
margin: 2px;
border: 1px solid #EEE;

color: #DDD;
}

</style>

<?php if($getBasename == 'blog') include '../footer.php'; else include 'footer.php'; ?>