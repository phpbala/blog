<?php 
include('header.php');
include '../class/user.class.php'; 
$user = new user(); $user->checkLogin();
$msg = '';
if(isset($_POST['save'])){   extract($_POST);
    if($user_type_id!=''){
                
        $query = $db->query("select user_type_id from tbl_privilege WHERE `user_type_id`='".$user_type_id."' AND `permission_id`='".$permission_id."'");
        if($query->num_rows==0){
            $db->query("INSERT INTO tbl_privilege (`user_type_id`, `permission_id`) values ('".$user_type_id."','".$permission_id."')");
        }else{
            $db->query("UPDATE tbl_privilege SET `permission_id`='".$permission_id."' where `user_type_id`='".$user_type_id."')");
        }        
        $msg = 'Privilege has been added successfuly !'; 
    } 
}
?>
<div class="container">    
    <div class="section"></div>
    <div class="row">
        <?php include('lhs.php'); ?>
        <div class="col l10">
            <div class="row">
                <h1 class="reduceFont blue-text">Manage Privilege</h1>
                <!--<hr>-->
                <div class="col l12 s12">
                    <span id="ajax_op"><?=$msg?></span>
                    <form method="post" id="privilege" enctype="multipart/form-data">
                               
                            <div class="row">
                                <div class="input-field col s12 l12"> 
                                    <select name="user_type_id" required="">
                                        <option value="" disabled selected>Choose User Type</option>
                                        <?php 
                                        $results = $db->query("select user_type,user_type_id from tbl_user_type");
                                        while($result = $results->fetch_object()){ 
                                        ?>
                                        <option value="<?=$result->user_type_id;?>" <?=(isset($edit) && $edit->user_type_id==$result->user_type_id)?'selected="selected"':''?>><?=$result->user_type;?></option>
                                        <?php }?>
                                      </select>
                                    <label>Select User Type</label>
                                    </div>                               
                            </div> 
                        
                            <div class="row">
                                <div class="input-field col s12 l12"> 
                                    <select name="permission_id" required="">
                                        <option value="" disabled selected>Choose Permission</option>
                                        <?php 
                                        $results = $db->query("select permission,permission_id from tbl_permission");
                                        while($result = $results->fetch_object()){ 
                                        ?>
                                        <option value="<?=$result->permission_id;?>"><?=$result->permission;?></option>
                                        <?php }?>
                                      </select>
                                    <label>Select Permission</label>
                                    </div>                               
                            </div>                     
                            <div class="row">
                                <div class="input-field col s12 l12">
                                   <input type="submit" name="save" value="Save" class="white-text btn btn-flat red">
                                </div>
                            </div>
                     </form>
                    <?php if(!isset($_GET['edit'])){ ?>
                        <table class="bordered">
                                <thead>
                                  <tr>
                                      <th data-field="category">User Type</th>
                                      <th data-field="name">Permission</th>
                                  </tr>
                                </thead>
                                <tbody>
                                <?php 
                                    $results = $db->query("select ut.user_type,p.permission from tbl_privilege tp LEFT JOIN tbl_user_type ut ON ut.user_type_id=tp.user_type_id LEFT JOIN tbl_permission p ON p.permission_id=tp.permission_id");
                                    while($result = $results->fetch_object()){ 
                                ?>
                                  <tr>
                                    <td><?=$result->user_type?></td>
                                    <td><?=$result->permission?></td>
                                  </tr>
                                 <?php }?>
                                </tbody>
                         </table>
                        <?php }?>
                </div>
            </div>
        </div>                
    </div>
</div>       
<?php include('footer.php'); ?> 