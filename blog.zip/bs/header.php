<?php 
include 'blog-admin/config.php'; 
$uri_parts = explode('?', $_SERVER['REQUEST_URI'], 2); 
$meta_title = ' Biography';  $meta_keywords = 'BA Samson';  $meta_description = 'Welcome to basamson';
$activePage = (isset($_GET['q']) || isset($_GET['cat_name']) || isset($_GET['tag_name']))?'blog.html':  basename($_SERVER['REQUEST_URI']);
if(isset($_GET['q']) && $_GET['q']!=''){ # If Single Post Page
    $title = $_GET['q'];
    $queryQ  = $db->query("SELECT p.real_title,p.content,"
                         ." (SELECT GROUP_CONCAT(DISTINCT(t.real_tag)) from tbl_tag_link tl LEFT JOIN tbl_tags t ON t.tag_id=tl.tag_id WHERE tl.post_id=p.post_id) as real_tags "
                         . "FROM `tbl_post` p left join tbl_users u ON u.user_id=p.user_id WHERE `title`='".$title."'");
    if($queryQ->num_rows > 0){
    $fetMeta          = $queryQ->fetch_object();
    $meta_title       = ' Post :'.$fetMeta->real_title; 
    $meta_keywords    = $fetMeta->real_tags;
    $meta_description = str_limit(strip_tags(htmlspecialchars_decode($fetMeta->content)), 80); 
    }
}
if(isset($_GET['cat_name']) && $_GET['cat_name']!=''){ $category_name = $_GET['cat_name'];
    $queryC  = $db->query("SELECT tc.real_category,p.content,"
                         ." (SELECT GROUP_CONCAT(DISTINCT(t.real_tag)) from tbl_tag_link tl LEFT JOIN tbl_tags t ON t.tag_id=tl.tag_id WHERE tl.post_id=p.post_id) as real_tags "
                         . "FROM `tbl_post` p left join tbl_users u ON u.user_id=p.user_id LEFT JOIN `tbl_category` tc on tc.category_id=p.category_id  WHERE tc.category='".$category_name."' limit 1");
    if($queryC->num_rows > 0){
        $fetMeta          = $queryC->fetch_object();
        $meta_title       = 'Category : '.$fetMeta->real_category; 
        $meta_keywords    = $fetMeta->real_tags;
        $meta_description = str_limit(strip_tags(htmlspecialchars_decode($fetMeta->content)), 80);  
    }
}
if(isset($_GET['tag_name']) && $_GET['tag_name']!=''){ $tag_name = $_GET['tag_name']; 
    $queryT  = $db->query("SELECT t.real_tag,p.content,"
                         ." (SELECT GROUP_CONCAT(DISTINCT(t.real_tag)) from tbl_tag_link tl LEFT JOIN tbl_tags t ON t.tag_id=tl.tag_id WHERE tl.post_id=p.post_id) as real_tags "
                         . "FROM `tbl_post` p left join tbl_users u ON u.user_id=p.user_id LEFT JOIN tbl_tag_link tl ON tl.post_id=p.post_id LEFT JOIN tbl_tags t ON t.tag_id=tl.tag_id "
                         . "WHERE t.tag='".$tag_name."' GROUP BY p.post_id limit 1");
    if($queryT->num_rows > 0){
    $fetMeta          = $queryT->fetch_object();
    $meta_title       = 'Tag : '.$fetMeta->real_tag; 
    $meta_keywords    = $fetMeta->real_tags;
    $meta_description = str_limit(strip_tags(htmlspecialchars_decode($fetMeta->content)), 80);  
    }
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>BA Samson 100 - <?=$meta_title;?></title> 
<link rel="icon"  href="<?=BASE_URL?>images/favi-icon.png" type="image/png" sizes="16x16">
<link rel="stylesheet" href="<?=BASE_URL?>css/style.css">
<meta name="description" content="<?=$meta_description?>">
<meta name="keywords" content="<?=$meta_keywords?>">
<meta name="author" content="BA SAMSON">
<link rel='canonical' href='<?='http://' . $_SERVER['HTTP_HOST'] . $uri_parts[0]?>'/>
<!--[if IE]>
  <script src="<?=BASE_URL?>http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->
</head>
<style>
    .textwrap{ float: left; margin: 10px;}
    .blog-content .post-list h2{ margin: 0px; padding: 0px;}
</style>
<body >
<div class="wrapper">
    <header class="bas-header">
        <div class="header">
        	<div class="logo-section">
                <?php ?>
            	<a href="<?=BASE_URL?>index.html"><img src="<?=BASE_URL?>images/logo.png" alt="Benjamin Abraham Samson"></a>
            </div>
            <div class="menu-section">
            	<nav>
                	<ul class="nav">
                        <li <?php if($activePage=='index.html'){?>class="current"<?php }?>><a href="#index.html">Home</a></li>
                        <li <?php if($activePage=='biography.html'){?>class="current"<?php }?>><a href="#biography.html">Biography</a></li>
                        <li class="sub-menu"><a href="#javascript:;">The Navy</a>
                            <ul>
                                <li><a href="#immts-dufferin.html">IMMTS Dufferin</a></li>
                                <li><a href="#wwii.html">WWII in the Royal Indian Navy</a></li>
                                <li><a href="#ins-valsura.html">INS Valsura</a></li>
                                <li><a href="#ins-jamuna.html">INS Jamuna</a></li>
                                <li><a href="#ins-sutlej.html">INS Sutlej</a></li>
                                <li><a href="#independence.html">Independence</a></li>
                                <li><a href="#first-naval-attache.html">First Naval Attache, London</a></li>
                                <li><a href="#commander-ins-delhi.html">Commander, INS Delhi</a></li>
                               	<li><a href="#cheif-of-personnel.html">Chief of Personnel</a></li>
                                <li><a href="#flag-captain-ins-delhi.html">Flag Captain INS Delhi & Naval Dockyard Bombay</a></li>
                                <li><a href="#commandant-national-defence-academy.html">Commandant, National Defence Academy</a></li>
                                <li><a href="#royal-college.html">Royal College of Defence Studies, London</a></li>
                                <li><a href="#flag-officer-commanding.html">Flag Officer Commanding Indian Fleet</a></li>                                
                            </ul>
                        </li>
                        <li class="sub-menu off-lf-pad"><a href="#javascript:;">Offshore Life</a>
                        	<ul>
                                <li><a href="#ceo-mazagon-docks.html">CEO Mazagon Docks Ltd</a></li>
                                <li><a href="#cii.html">CII</a></li>
                                <li><a href="#chairman-philips-india.html">Chairman Philips India</a></li>
                                <li><a href="#vicechairman-damodar.html">Vice Chairman Damodar Bulk Carriers</a></li>
                            </ul>
                        </li>
                       <li><a href="#gallery.html">Gallery</a></li>
                        <li class="sub-menu"><a href="#javascript:;">Family</a>
                        	<ul>
                                <li><a href="#bene-israelite-community.html">Bene Israelite Community</a></li>
                                <li><a href="#javascript:;">Samson Family</a></li>
                                <li><a href="#javascript:;">My Father</a></li>
                            </ul>
                        </li>                       
                        <li <?php if($activePage=='blog'){?>class="current"<?php }?>><a href="<?=BASE_URL?>blog">Blog</a></li>
    			</ul>
                </nav>
            </div>
        </div>
    </header>
   <div class="clearfix"></div>