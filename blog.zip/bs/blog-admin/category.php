<?php
include('header.php');
include '../class/user.class.php'; 
$user = new user(); $user->checkLogin();
$msg = '';

$start=0;
$limit=10;

if(isset($_GET['id'])){
	$id=$_GET['id'];
	$start=($id-1)*$limit; 
}else{
	$id=1;
}

if(isset($_POST['save'])){    extract($_POST);
    if(isset($_POST['edit']) && $_POST['edit']!=''){ $category_id = (int)$_POST['edit'];
          if($_POST['category']!=''){
            $q = $db->query("select * from tbl_category WHERE `category`='".$db->real_escape_string(clean($category))."' and category_id!=".$category_id);
            if($q->num_rows == 0){
            $db->query("UPDATE tbl_category SET `category`='".$db->real_escape_string(clean($category))."',`real_category`='".$db->real_escape_string($category)."' WHERE category_id=".$category_id);
            header("location:category.php");
            }else{
                $msg = 'Sorry, This category already exist !';
            }
          }else{
            $msg = 'Please enter the category !'; 
        }
    }  else{
        if($_POST['category']!=''){
            $q = $db->query("select * from tbl_category WHERE `category`='".$db->real_escape_string(clean($category))."'");
            if($q->num_rows == 0){
            $db->query("insert into tbl_category (`user_id`, `category`, `real_category`) values("
                        . "'".$_SESSION['user_id']."',"
            . "'".$db->real_escape_string(clean($category))."','".$db->real_escape_string($category)."')");
            $msg = 'New category has been created successfuly !'; 
            }else{
                $msg = 'Sorry, This category already exist !';
            }
        }else{
            $msg = 'Please enter the category !'; 
        }
    }
}
if(isset($_GET['edit']) && $_GET['edit']!=''){ $category_id = (int)base64_decode($_GET['edit']);
    $query = $db->query("select * from tbl_category where category_id=".$category_id);
    $edit = $query->fetch_object();
}
if(isset($_GET['trash']) && $_GET['trash']!=''){ $category_id = (int)base64_decode($_GET['trash']);
    $query = $db->query("DELETE from tbl_category where category_id=".$category_id);
    $msg = 'Category has been deleted successfuly!';
}
?>
<div class="container">    
    <div class="section"></div>
    <div class="row">         
     <?php include('lhs.php');?>         
        <div class="col l10">
           <div class="row">
            <h1 class="reduceFont">All Blog Categories</h1>
            <form method="post" id="ajaxCategory" enctype="multipart/form-data">
                            <div class="row">
                                <div class="input-field col s12 l12">                        
                                    <input id="title" name="category" type="text" required class="validate" value="<?=(isset($edit))?$edit->real_category:'';?>">
                                    <input type="submit" name="save" value="Save" class="white-text btn btn-flat red"> 
                                    <?php echo $msg; if(isset($_GET['edit'])&&$_GET['edit']!=''){?><input type="hidden" name="edit" value="<?=$category_id?>">
                                    <input type="button" name="back" onclick="document.location.href='category.php';" value="Back" class="btn waves-effect waves-teal"><?php }?>
                                  <label for="title">Add New Category</label>
                                </div>
                            </div>
                     </form>
            <?php if(!isset($_GET['edit'])){ 
            $resultT = $db->query("select category_id,category from tbl_category");
            if($resultT->num_rows > 0){
            ?>
            <table class="bordered">
                    <thead>
                      <tr>
                          <th data-field="category">Category</th>
                          <th align="center" data-field="name">Action</th>
                      </tr>
                    </thead>
                    <tbody>
                    <?php 
                        $results = $db->query("select category_id,category,real_category from tbl_category LIMIT $start, $limit");
                        while($result = $results->fetch_object()){  
                    ?>
                      <tr>
                        <td><?=$result->real_category?></td>
                        <td><a href="./category.php?edit=<?php echo base64_encode($result->category_id);?>" class="blue-text"><i class="tiny material-icons">mode_edit</i></a> &nbsp; 
                        <?php if($user->permission()->id==1){ ?><a onclick="return deleteIt();" href="./category.php?trash=<?php echo base64_encode($result->category_id);?>" class="blue-text">
                            <i class="tiny material-icons">mode_delete</i></a>
                        <?php }?>
                        </td>
                      </tr>
                        <?php }?>
                    </tbody>
             </table>
            <ul class="pagination">              
            <?php
                //fetch all the data from database.
                $rows=$resultT->num_rows;
                //calculate total page number for the given table in the database 
                $total=ceil($rows/$limit);?>
                <ul class='page'>
                <?php if($id>1)
                {
                        //Go to previous page to show previous 10 items. If its in page 1 then it is inactive
                        echo '<li><a href="?id='.($id-1).'"><i class="material-icons">chevron_left</i></a></li>';
                }else{
                        echo '<li class="disabled"><a href="javascript:;"><i class="material-icons">chevron_left</i></a></li>';
                }
                
                ?>

                <?php
                for($i=1;$i<=$total;$i++)
                {
                        if($i==$id) { echo "<li class='active'>".$i."</li>"; }

                        else { echo '<li class="waves-effect"><a href="?id='.$i.'">'.$i.'</a></li>'; }
                }
                if($id!=$total)
                {
                        ////Go to previous page to show next 10 items.
                        echo '<li class="waves-effect"><a href="?id='.($id+1).'"><i class="material-icons">chevron_right</i></a></li>';
                }else{
                        echo '<li class="disabled"><a href="javascript:;"><i class="material-icons">chevron_right</i></a></li>';
                }
                ?>
            </ul>
            <?php }else{?>
            <h5>No Categories Found</h5>
            <?php }}?>
            </div>
        </div>
        
        
    </div>
</div>

<script>
// Replace the <textarea id="editor1"> with a CKEditor
// instance, using default configuration.
CKEDITOR.replace( 'editor1' );
</script>        

<?php include('footer.php'); ?>


        