<?php
include_once('../blog-admin/config.php');
$category_name = $_REQUEST['category_name'];
$pQuery=$db->query("SELECT count(*) as total_post_count,tc.real_category  from tbl_post p LEFT JOIN `tbl_category` tc on tc.category_id=p.category_id WHERE p.status = '1' AND tc.`category`='".$category_name."'");
$pCF     = $pQuery->fetch_object();
$total_post_count = $pCF->total_post_count;
$count  = $total_post_count; 
$page = (int) (!isset($_REQUEST['pageId']) ? 1 :$_REQUEST['pageId']);
$page = ($page == 0 ? 1 : $page);
$recordsPerPage = 10; 
$start = ($page-1) * $recordsPerPage; 
$adjacents = "2";

$prev = $page - 1;
$next = $page + 1;
$lastpage = ceil($count/$recordsPerPage); 
$lpm1 = $lastpage - 1; 
$pagination = "";
if($lastpage > 1)
    {   
        $pagination .= '<div class="pagination-section"><ul class="pagination"><li class="pag-first"><a href="#Page=1" onClick="changePagination(1)"></a></li>';
        if ($page > 1)
            $pagination.= "<li class='pag-previous'><a href=\"#Page=".($prev)."\" onClick='changePagination(".($prev).");'></a></li>"; 
        else
            $pagination.= "<li class='pag-previous'><a href='javascript:;'></a></li>";   
        if ($lastpage < 7 + ($adjacents * 2))
        {   
            for ($counter = 1; $counter <= $lastpage; $counter++)
            {
                if ($counter == $page)
                    $pagination.= "<li class='active'><a href='javascript:;'>".$counter."</a></li>";
                else
                    $pagination.= "<li><a href=\"#Page=".($counter)."\" onClick='changePagination(".($counter).");'>$counter</a></li>";     

            }
        }   

        elseif($lastpage > 5 + ($adjacents * 2))
        {
            if($page < 1 + ($adjacents * 2))
            {
                for($counter = 1; $counter < 4 + ($adjacents * 2); $counter++)
                {
                    if($counter == $page)
                        $pagination.= "<li class='active'><a href='javascript:;'>".$counter."</a></li>";
                    else
                        $pagination.= "<li><a href=\"#Page=".($counter)."\" onClick='changePagination(".($counter).");'>$counter</a></li>";     
                }
                $pagination.= "...";
                $pagination.= "<li><a href=\"#Page=".($lpm1)."\" onClick='changePagination(".($lpm1).");'>$lpm1</a></li>";
                $pagination.= "<li><a href=\"#Page=".($lastpage)."\" onClick='changePagination(".($lastpage).");'>$lastpage</a></li>";   

           }
           elseif($lastpage - ($adjacents * 2) > $page && $page > ($adjacents * 2))
           {
               $pagination.= "<li><a href=\"#Page=\"1\"\" onClick='changePagination(1);'>1</a></li>";
               $pagination.= "<li><a href=\"#Page=\"2\"\" onClick='changePagination(2);'>2</a></li>";
               $pagination.= "...";
               for($counter = $page - $adjacents; $counter <= $page + $adjacents; $counter++)
               {
                   if($counter == $page)
                       $pagination.= "<li class='active'><a href='javascript:;'>".$counter."</a></li>";
                   else
                       $pagination.= "<li><a href=\"#Page=".($counter)."\" onClick='changePagination(".($counter).");'>$counter</a></li>";     
               }
               $pagination.= "..";
               $pagination.= "<li><a href=\"#Page=".($lpm1)."\" onClick='changePagination(".($lpm1).");'>$lpm1</a></li>";
               $pagination.= "<li><a href=\"#Page=".($lastpage)."\" onClick='changePagination(".($lastpage).");'>$lastpage</a></li>";   
           }
           else
           {
               $pagination.= "<li><a href=\"#Page=\"1\"\" onClick='changePagination(1);'>1</a></li>";
               $pagination.= "<li><a href=\"#Page=\"2\"\" onClick='changePagination(2);'>2</a></li>";
               $pagination.= "..";
               for($counter = $lastpage - (2 + ($adjacents * 2)); $counter <= $lastpage; $counter++)
               {
                   if($counter == $page)
                        $pagination.= "<li class='active'><a href='javascript:;'>$counter</a></li>";
                   else
                        $pagination.= "<li><a href=\"#Page=".($counter)."\" onClick='changePagination(".($counter).");'>$counter</a></li>";     
               }
           }
        }
        if($page < $counter - 1)
            $pagination.= "<li class='pag-next'><a href=\"#Page=".($next)."\" onClick='changePagination(".($next).");'></a></li>";
        else
            $pagination.= "<li class='pag-next'><a href='javascript:;'></a></li>";

        $pagination.= "<li class='pag-last'><a href=\"#Page=".($lastpage)."\" onClick='changePagination(".($lastpage).");'></a></li></ul></div>";        
    }

if(isset($_POST['pageId']) && !empty($_POST['pageId']))
{
    $id=$_POST['pageId'];
}
else
{
    $id='0';
}
$query="SELECT p.title,p.real_title,p.content,p.image,p.created_date,u.firstname,u.lastname,"
                         . "(SELECT GROUP_CONCAT(DISTINCT(t.tag)) from tbl_tag_link tl LEFT JOIN tbl_tags t ON t.tag_id=tl.tag_id WHERE tl.post_id=p.post_id) as tags, "
                         ." (SELECT GROUP_CONCAT(DISTINCT(t.real_tag)) from tbl_tag_link tl LEFT JOIN tbl_tags t ON t.tag_id=tl.tag_id WHERE tl.post_id=p.post_id) as real_tags "
                         . "FROM `tbl_post` p left join tbl_users u ON u.user_id=p.user_id LEFT JOIN `tbl_category` tc on tc.category_id=p.category_id  WHERE p.status ='1' AND tc.category='".$category_name."' ORDER BY p.post_id DESC LIMIT ".$db->escape_string($start).",$recordsPerPage";
//echo $query;
$res    =   $db->query($query);
$count  =   $res->num_rows;
$HTML=''; $i=0;
if($count > 0){
while($fp=$res->fetch_object()){ 
    $tags = explode(",", $fp->tags); $real_tag = explode(",", $fp->real_tags);
    ?>
    
<div class="blog-content <?=($i==0)?'first':'';?>">
    <h2><?=ucfirst($fp->real_title)?></h2> 
    <div class="author-date"><span class="author"><?=$fp->firstname?></span><span class="date"><?=ordinal(date('d',  strtotime($fp->created_date))).date(' M Y',  strtotime($fp->created_date))?></span></div>
    <div class="related-tags">
        <span>Related Tags :</span>
        <?php foreach($tags as $key=>$tag){ ?><a href="<?=BASE_URL?>blog/tag/<?=$tag?>" ><?=$real_tag[$key]?></a><?php }?>
    </div>
    <div class="post-list" style="padding-top:10px;">
        <img src="<?=BASE_URL.'uploads/sm/'.$fp->image?>" width="180" class="textwrap">
    <?php 
    $content = $fp->content;
    $content = preg_replace("/<img[^>]+\>/i", "", $content);
    echo html_entity_decode(str_limit($content,475),ENT_QUOTES);?>
    </div> <div class="clearfix"></div>
    <a href="<?=BASE_URL?>blog/post/<?=$fp->title;?>"><span class="read-mre">Read More</span></a>
  </div>

<?php }
}
else
{
    $HTML='<h2 align="right" style="padding-right:30px; font-size:2em;">No Blog Post Found</h2>';
}
echo $HTML;
echo $pagination;
?>