<?php
class msg{
    public function alert($msg=""){
        return ($msg!='')?'<script>$(document).ready(function(){ Materialize.toast("'.$msg.'", 4000,"rounded") });</script>':'';
    }
    public function success($msg=""){
        return ($msg!='')?'<div class"alert alert-success">'.$msg.'</div>':'';
    }
    public function warning($msg=""){
        return ($msg!='')?'<div class"alert alert-warning">'.$msg.'</div>':'';
    }
    public function danger($msg=""){ 
        return ($msg!='')?'<div class"alert alert-danger">'.$msg.'</div>':'';
    }
    public function info($msg=""){        
        return ($msg!='')?'<div class"alert alert-info">'.$msg.'</div>':'';
    }
}