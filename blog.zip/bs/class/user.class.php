<?php
class user{ 
    public function creation(){ $msg = ''; 
        if(isset($_POST['save'])){    extract($_POST);
                if(isset($_POST['edit']) && $_POST['edit']!=''){ $user_id = (int)$_POST['edit'];
                      if($_POST['username']!='' && $_POST['email']!=''){ extract($_POST);
                      $queryC = $db->query("select email from tbl_users WHERE (email='".$email."' OR username='".$username."') AND user_id!=".$user_id);
                        if($queryC->num_rows>0){
                            $msg = 'Sorry, This user already exist!';
                        }else{
                            $db->query("UPDATE tbl_users SET `firstname`='".$db->real_escape_string($firstname)."',`lastname`='".$db->real_escape_string($lastname)."',"
                                    . "`username`='".$db->real_escape_string($username)."',`email`='".$db->real_escape_string($email)."',"
                                    . "`password`='".$db->real_escape_string($password)."',`user_type_id`='".$db->real_escape_string($user_type_id)."' "
                                    . "WHERE user_id=".$user_id);
                            header("location:users.php");
                        }
                      }else{
                           $msg = 'Please fill out the required fields !'; 
                    }
                }  else{
                    if($_POST['username']!='' && $_POST['email']!=''){  extract($_POST); $password = time().'@basamson$%';
                        $queryC = $db->query("select email from tbl_users WHERE email='".$email."' OR username='".$username."'");
                        if($queryC->num_rows>0){
                            $msg = 'Sorry, This user already exist!';
                        }else{
                        $db->query("insert into tbl_users (`firstname`, `lastname`, `username`, `email`, `password`, `user_type_id`) "
                                . "values('".$db->real_escape_string($firstname)."','".$db->real_escape_string($lastname)."',"
                                . "'".$db->real_escape_string($username)."','".$db->real_escape_string($email)."','".$db->real_escape_string($password)."','".$db->real_escape_string($user_type_id)."')");
                        # Mail Function here

                        $msg = 'New user has been created successfuly !'; 
                        }
                    }else{
                        $msg = 'Please fill out the required fields !'; 
                    }
                }
            } return $msg;
    }
    public function action(){
        if(isset($_GET['trash']) && $_GET['trash']!=''){ $us_id = (int)base64_decode($_GET['trash']);
            $db->query("DELETE from tbl_users where user_id=".$us_id);
            return $msg = 'User has been deleted successfuly !';
        }
        if(isset($_GET['deactivate']) && $_GET['deactivate']!=''){ $u_id = (int)base64_decode($_GET['deactivate']);
            $db->query("UPDATE tbl_users SET `status`='0' where user_id=".$u_id);
            return $msg = 'User has been deactivated successfuly !';
        }
        if(isset($_GET['activate']) && $_GET['activate']!=''){ $use_id = (int)base64_decode($_GET['activate']);
            $db->query("UPDATE tbl_users SET `status`='1' where user_id=".$use_id);
            return $msg = 'User has been activated successfuly !';
        }
    }
    public function login(){
        if(isset($_POST['doLogin'])){ extract($_POST); 
            try{
                $db = new mysqli(host,user,password,database);
                $query = $db->query("select * from tbl_users where username='".$db->escape_string($username)."' and password='".md5($db->escape_string($password))."'"); 
                if($query->num_rows==1){
                    $result = $query->fetch_object();
                    if($result->status==1){
                        $_SESSION['user_id'] = $result->user_id;
                        $_SESSION['user_type_id'] = $result->user_type_id; 
                        header("location:./"); exit; 
                    }else{
                        return msg::alert("Sorry, Your account is not activate yet !");
                    }
                }else{
                    return msg::alert("Sorry, username or password is incorrect!");
                }
                
            }catch(Exception $e){
                echo $e->getPrevious();
            }
        }
    }
    public function logout(){
        if(isset($_GET['logout']) && $_GET['logout']=='true'){
            if(isset($_SESSION['user_id'])) session_destroy();
            header("location:./index.php");
        }
    }
    public function checkLogin(){
            if(!isset($_SESSION['user_id'])) header("location:./index.php");
    }
    public function permission(){           
        try{ $result = (object)array('id'=>1,'privilege'=>'read'); # Else Normal Users
            if(isset($_SESSION['user_type_id'])){
                    $db = new mysqli(host,user,password,database);
                    $query = $db->query("select tp.user_type_id id,p.permission privilege from tbl_privilege tp LEFT JOIN tbl_permission p on p.permission_id=tp.permission_id "
                            . "where tp.user_type_id='".$_SESSION['user_type_id']."'"); 
                    if($query->num_rows==1){ 
                        $result = $query->fetch_object(); 
                    }           
            }
            return $result; 

        }catch(Exception $e){
            echo $e->getMessage(); 
        }
    }
    
}