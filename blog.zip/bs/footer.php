<?php
$interLinkPage = 'blog.html?'; $pageLink = 'blog.html';
if(isset($_GET['cat_name']) && $_GET['cat_name']!=''){ $category_name = $_GET['cat_name']; # it is for category
    $pageLink = 'category/'.$category_name;
    $interLinkPage = 'category/'.$category_name.'&'; 
}elseif(isset($_GET['tag_name']) && $_GET['tag_name']!=''){ $tag_name = $_GET['tag_name']; # it is for category
    $pageLink = 'tag/'.$tag_name;
    $interLinkPage = 'tag/'.$tag_name.'&'; 
} 
?>
<div class="clearfix"></div>
<footer class="footer-cnt">
       <div class="footer">
       		<div class="foot-logo">
            	<img src="<?=BASE_URL?>images/wheel.png" alt="Wheel" title="wheel" />
            </div>
           <div class="footer-line">
               <div class="samson-sign"></div>
               <div class="next-page-name"> 
                   <?php if(isset($_GET['page'])){ 
                   $prev = ($prevPage>=1)?$interLinkPage.'page='.$prevPage:$pageLink;
                    $prevUrl = BASE_URL.$prev;    
                   ?>
                   <link rel='prev' href='<?=$prevUrl?>'/>
                   <span  class="prev-page left"><a href="<?=BASE_URL?><?=($prevPage>=1)?$interLinkPage.'page='.$prevPage:$pageLink?>">Prev</a></span><?php }?>&nbsp;
                  <?php  
                   # $offset<$total_post_count && $setLimit<$total_post_count 
                   if(isset($checkCount) && $checkCount<$total_post_count){ $nextUrl = BASE_URL.$interLinkPage.'page='.$nextPage;  ?>
                   <link rel='next' href='<?=$nextUrl?>'/>
                   <span  class="next-page right"><a href="<?=BASE_URL.$interLinkPage?>page=<?=$nextPage?>">Next</a></span><?php }?>                   
<!--                   <a class="next-page-title" href="<?=BASE_URL?>immts-dufferin.html">THE NAVY : IMMTS Dufferin</a>-->
               </div>
           </div>
       </div>
   </footer>
</div>
<script src="<?=BASE_URL?>js/jquery-1.9.1.js"></script>
<script src="<?=BASE_URL?>js/script.js" type="text/javascript"></script>
</body>
</html>