<?php
$sql= $db->query("select username from tbl_users WHERE user_id=".$_SESSION['user_id']); 
$f  = $sql->fetch_object(); 
?>
<div class="col l2"> 
<h2 class="menu section reduceFont">Welcome <?=str_limit($f->username,8)?></h2>
            <ul class="collection">
                <li class="collection-item"><a href="<?php echo HTTP;?>list.php" class="blue-grey-text">Show All Post</a></li>  
                <li class="collection-item"><a href="<?php echo HTTP;?>" class="blue-grey-text">Add Post</a></li> 
                <?php if($user->permission()->id==1 || $user->permission()->id==2){ ?>
                <li class="collection-item"><a href="<?php echo HTTP;?>category.php" class="blue-grey-text">All Category</a></li>
                <li class="collection-item"><a href="<?php echo HTTP;?>tags.php" class="blue-grey-text">All Tags</a></li>
<!--                <li class="collection-item"><a href="<?php echo HTTP;?>users.php" class="blue-grey-text">All Users</a></li>
                <?php if($user->permission()->id==1){ ?> 
                <li class="collection-item"><a href="<?php echo HTTP;?>privileges.php" class="blue-grey-text">All Privileges</a></li>
                <?php }?>-->
                <?php }?>
                <li class="collection-item"><a href="<?php echo HTTP;?>change-password.php" class="blue-grey-text">Change Password</a></li>
                <li class="collection-item"><a href="<?php echo HTTP;?>?logout=true" class="blue-grey-text">Logout</a></li>
              </ul>
</div>
            