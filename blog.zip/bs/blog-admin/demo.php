<script>
$("#ajaxPost").submit(function(){ 
         
        var postTitle = $("#title").val(); 
            $("#ajaxPost").removeAttr('onsubmit');
            if(postTitle==''){
                $(".r-title").show();
                $("#title").focus();
                return false;
            }
            if($('#editor1').val()==''){ $(".r-title").hide();
                $(".r-content").show(); 
                 return false;
            }
            if($('#category_id').val()==''){ $(".r-content").hide();
                $(".r-category").show();
                $("#category_id").focus();
                 return false;
            }
            if($('#tags').val()==''){ $(".r-category").hide();
                $(".r-tag").show();
                $("#tags").focus();
                 return false;
            }
            
            for (instance in CKEDITOR.instances ) {
                    CKEDITOR.instances[instance].updateElement();
                }
            var formObj = $(this);
            var formURL = formObj.attr("action");

            if(window.FormData !== undefined)  // for HTML5 browsers
            {

                var formData = new FormData(this);
                $.ajax({
                    url: formURL,
                    type: 'POST',
                    data:  formData,
                    mimeType:"multipart/form-data",
                    contentType: false,
                    cache: false,
                    processData:false,
                    success: function(data, textStatus, jqXHR)
                    {// required
                        alert(data); return false;
                            if(data == 'required'){ var req = "Please fill out the required fields !";
                                alert(req);
                                $("#ajax_op").html(req);
                            }else if(data == 'error'){
                                alert(data);
                                $("#ajax_op").html(data);
                            }else if(data == 'exist'){ var exist = "Sorry, This post '"+postTitle+"' already exist !";
                                alert(exist);
                                $("#ajax_op").html(exist);
                            }else if(data == 'logout'){ alert("Sorry, Session has been expired !");
                                document.location.href = './';
                            }else{ 
                                $("#ajax_op").html(data);
                                document.location.href = 'list.php'; 
                            }
                    },
                    error: function(jqXHR, textStatus, errorThrown) 
                    {
                            $("#ajax_op").html(textStatus); 
                    }           
               });
                e.preventDefault();
                e.unbind();
           }  
});
</script>