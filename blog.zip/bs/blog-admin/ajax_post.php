<?php
include_once 'config.php';
include '../vendor/autoload.php';
if(!isset($_SESSION['user_id'])){ echo "logout"; exit; }
# Post creation & updation 
if(isset($_POST['title'],$_POST['content'])){ 
    $msg = '';   
    
    $post_save_publish = (isset($_POST['publish']))?'1':'0';
    
    if($_POST['title']!='' && $_POST['content']!='' && $_POST['category_id']!='' && $_POST['tags']!=''){ 
        # `user_id`, `title`, `content`, `tags`, `category_id`, `image`
        $filename = '';
        if($_FILES['upload']['name']!=''){ 
            if($_FILES['upload']['size'] > 1048576){
                //You can not upload this file
                echo 'max_size_1M'; exit;
              }else{
            $ext = pathinfo($_FILES['upload']['name'], PATHINFO_EXTENSION);
            $filename    = time().$_FILES['upload']['name'];
            $temp_name   = $_FILES['upload']['tmp_name'];
            $destination = "../uploads/large/".$filename;
            $md_destination = "../uploads/md/".$filename;
            $sm_destination = "../uploads/sm/".$filename;
            move_uploaded_file($temp_name, $destination);            
            $image = new \Eventviva\ImageResize($destination); 
            
            $image->quality_jpg = 300;
            
            $image->resize(600, 400); # medium
            $image->save($md_destination);
            $image->resize(250, 180); # small
            $image->save($sm_destination);
            }
        }
        extract($_POST); $post_is = 'insert';
        if(!isset($_POST['edit'])){   
        $que = $db->query("SELECT title from tbl_post WHERE `title`='".$db->real_escape_string(clean($title))."'");
        if($que->num_rows == 0){
            $db->query("insert into tbl_post (`user_id`, `title`, `real_title`, `content`, `category_id`, `image`,`status`) values("
                    . "'".$_SESSION['user_id']."',"
                    . "'".$db->real_escape_string(clean($title))."',"
                    . "'".$db->real_escape_string($title)."',"
                    . "'".$db->real_escape_string($content)."',"
                    . "'".$db->real_escape_string($category_id)."',"
                    . "'".$db->real_escape_string($filename)."',"
                    . "'".$post_save_publish."')");        
                $post_id = $db->insert_id; 
                $msg = 'New post has been created successfuly !';  
            }else{
                $msg = 'exist'; # Already Exist
            }
        }elseif(isset($_POST['edit']) && $_POST['edit']!=''){ $updateStatus = true;
            $post_id = $_POST['edit'];
            $que = $db->query("SELECT title from tbl_post WHERE `post_id`='".$post_id."'");
            $ft  = $que->fetch_object();
            if($ft->title != clean($title)){
                $quer = $db->query("SELECT title from tbl_post WHERE `title`='".$db->real_escape_string(clean($title))."'");
                if($quer->num_rows > 0){
                    $msg = 'exist'; # Already Exist
                    $updateStatus = false; 
                }
            }
            if($updateStatus == true){
                $image = ($filename!='')?",`image`='".$db->real_escape_string($filename)."'":'';
                $db->query("UPDATE tbl_post SET "
                    . "`title`='".$db->real_escape_string(clean($title))."',"
                    . "`real_title`='".$db->real_escape_string($title)."',"
                    . "`content`='".$db->real_escape_string($content)."',"
                    . "`category_id`='".$db->real_escape_string($category_id)."',"
                    . "`status`='".$post_save_publish."'"
                    . $image." WHERE `post_id`='".$post_id."'"); 
                $post_is = 'update';
                $msg = 'Post has been updated successfuly !';  
            }
        }else{
            echo "Error!"; exit;
        }
        
        if($_POST['tags']!=''){
            if($post_is=='update'){
                $db->query("DELETE FROM tbl_tag_link WHERE `post_id`='".$post_id."'");
            } 
            $tags = explode(",", $_POST['tags']); 
            foreach ($tags as $value){
                $r=$db->query("SELECT count(*) FROM tbl_tags WHERE tag='".$value."'");
                $count = $r->fetch_row();
                if($count[0]==0){ 
                    $db->query("insert into tbl_tags (`tag`,`real_tag`) values('".$db->real_escape_string(clean($value))."','".$db->real_escape_string($value)."')");
                    $db->query("insert into tbl_tag_link (`tag_id`,`post_id`) values('".$db->insert_id."','".$post_id."')");
                }else{
                    $query = $db->query("select tag_id from tbl_tags WHERE `tag`='".$db->real_escape_string($value)."'");
                    $result = $query->fetch_object();
                    $tagSql = $db->query("SELECT * from tbl_tag_link WHERE `tag_id`='".$result->tag_id."' AND `post_id`='".$post_id."'");
                    if($tagSql->num_rows == 0){
                        $db->query("insert into tbl_tag_link (`tag_id`,`post_id`) values('".$result->tag_id."','".$post_id."')");
                    }
                }

            }
        }
        echo $msg;        
    }else{
        echo "required"; exit;
    }
} 
else{ 
    if(isset($_POST['action'],$_POST['post_id'])){
        if($_POST['action'] == 'trash'){ 
            $db->query("DELETE from `tbl_post` where `post_id`=".$_POST['post_id']);
        }elseif($_POST['action'] == 'publish'){
            $db->query("UPDATE `tbl_post` SET `status`='1' where `post_id`=".$_POST['post_id']); 
        }elseif($_POST['action'] == 'unpublish'){
            $db->query("UPDATE `tbl_post` SET `status`='0' where `post_id`=".$_POST['post_id']);
        }
    }
}
# Post Publish & trash


