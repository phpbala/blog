<?php include('config.php'); ?>
<!DOCTYPE html>
  <html>
    <head>
      <!--Import Google Icon Font-->
      <link href="http://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet"> 
      
      <!--Import materialize.css-->
      <?php if(isset($_SESSION['user_id'])){ ?>
      <link type="text/css" rel="stylesheet" href="<?php echo HTTP; ?>css/materialize.97.min.css"  media="screen,projection"/>
      <?php }else{?>
     <link type="text/css" rel="stylesheet" href="<?php echo HTTP; ?>css/materialize.min.css"  media="screen,projection"/>
     <?php }?>
      <link type="text/css" rel="stylesheet" href="<?php echo HTTP; ?>css/materialize-tags.css"  media="screen,projection"/>
      <!--Let browser know website is optimized for mobile-->
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
      <style>
        .reduceFont{
            font-size: 21px;
        }
        .req { display: none;}
      </style>
    </head>
    
    <body>
      <!--Import jQuery before materialize.js-->
      <script type="text/javascript" src="<?php echo HTTP; ?>js/jquery.1.11.min.js"></script>
      <script type="text/javascript" src="<?php echo HTTP; ?>js/materialize.min.js"></script>
      <script type="text/javascript" src="<?php echo HTTP; ?>js/materialize-tags.js"></script>
      <script type="text/javascript"  src="<?php echo HTTP; ?>ckeditor/ckeditor.js"></script>
      
      <nav class="grey darken-3">
        <div class="nav-wrapper">
            <div class="center">
                <a href="#" class="brand-logo center">BA SAMSON BLOG ADMIN</a>
            </div>  
        </div>
      </nav>
      
      