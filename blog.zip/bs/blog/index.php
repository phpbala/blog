<?php 
$getBasename =  basename(getcwd());
if($getBasename == 'blog') include '../header.php'; else include 'header.php';
$setLimit = PER_PAGE_LIMIT; $offset = 0; $page =0;
$pQuery  = $db->query("SELECT count(*) as total_post_count from tbl_post WHERE `status`='1'");
$pCF     = $pQuery->fetch_object();
$total_post_count = $pCF->total_post_count;
?>
<script type="text/javascript" src="<?=BASE_URL?>blog/js/jquery-1.8.0.min.js"></script>
<script type="text/javascript">
$(document).ready(function(){  var PageId = '0';
    var hashId = window.location.hash.substr(1);
    var pattern = /Page=/i;
    var PageId = hashId.replace(pattern, '');
    changePagination(PageId);	
});
function changePagination(pageId){
     $(".flash").show();
     $(".flash").fadeIn(400).html
                ('Loading <img src="<?=BASE_URL?>blog/images/load.gif" />');
     var dataString = 'pageId='+ pageId;
     $.ajax({
           type: "POST",
           url: "<?=BASE_URL?>blog/loadBlog.php",
           data: dataString,
           cache: false,
           success: function(result){
           $(".flash").hide();
           $("#pageData").html(result);
           }
      });
}
</script>
<section class="content-section">
		<div class="blog-section">
        		<div class="sub-title-header">
                	<h2>Blog</h2>
                    <div class="navy-years">
                    </div>
                </div>        	
   	<div class="blog-container"> 
            <span class="flash"></span>
            <div class="blog-content-bx" id="pageData">
                 <!-- Ajax Data loadBlog -->
            </div>            
            <?php include 'side-bar.php'; ?>
          </div>
        </div>
</section> 

<?php if($getBasename == 'blog') include '../footer.php'; else include 'footer.php'; ?>