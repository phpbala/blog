<?php
include_once 'config.php';
$tags = array();
$query = $db->query("SELECT `real_tag` FROM tbl_tags");
if($query->num_rows > 0){
    while($obj = $query->fetch_object()){
        $tags[] = $obj->real_tag;
    }    
}
echo json_encode($tags);