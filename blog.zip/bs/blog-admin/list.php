<?php 
include('header.php');
include '../class/user.class.php'; 
$user = new user(); $user->checkLogin();

$start=0;
$limit=9;

if(isset($_GET['id'])){
	$id=$_GET['id'];
	$start=($id-1)*$limit;
}else{
	$id=1;
}

?>
<div class="container">    
    <div class="section"></div>
    <div class="row">         
     <?php include('lhs.php'); ?>  
        <div class="col l10">
           <div class="row">
            <h1 class="reduceFont">All Blog Posts</h1>
            <?php 
            $orderBy = " ORDER BY p.`created_date` DESC";
            $whereCon = ($user->permission()->id==1 || $user->permission()->id==2)?$orderBy:" WHERE u.user_id=".$_SESSION['user_id']." ".$orderBy;
            $queryF = $db->query("select p.*,u.username from tbl_post p left join tbl_users u on u.user_id=p.user_id ".$whereCon);
            $query = $db->query("select p.*,u.username from tbl_post p left join tbl_users u on u.user_id=p.user_id ".$whereCon." LIMIT $start, $limit"); 
            if($queryF->num_rows > 0){
            while($fetch = $query->fetch_object()){ ?>
                <div class="col s12 m6 l4 post-item-head">
                   <div class="card medium">
                        <div class="card-image"> 
                            <?php if($fetch->image!='' && file_exists("../uploads/large/".$fetch->image)){?><a target="_blank" href="../blog/post/<?=$fetch->title; ?>"><img src="../uploads/md/<?php echo $fetch->image; ?>"></a><?php }?>
                        </div> 
                          <div class="card-content">
                              <a href="../blog/post/<?=$fetch->title; ?>" target="_blank"><span class="card-title"><?php echo str_limit($fetch->real_title,25); ?></span></a>
                            <p><?php echo str_limit(html_entity_decode($fetch->content),40); ?></p> 
                            <?php if($user->permission()->id == 2 || $user->permission()->id == 1){?><p align="right"><small>-By <?php echo $fetch->username; ?></small></p><?php }?>
                          </div>
                           <div class="card-action center">
                               <a href="./?edit=<?php echo base64_encode($fetch->post_id);?>" class="blue-text"><i data-position="top" data-tooltip="Edit" class="tiny tooltipped material-icons">mode_edit</i></a>
                               <?php if($user->permission()->id == 2 || $user->permission()->id == 1){ if($fetch->status==1){ ?>
                               <a href="javascript:;" data-post-id="<?php echo $fetch->post_id;?>" data-post-action="unpublish" class="blue-text post-item">
                                   <i data-position="top" class="tiny material-icons">mode_done</i>
                               </a>
                               <?php }else{?>
                               <a href="javascript:;" data-post-id="<?php echo $fetch->post_id;?>" data-post-action="publish" class="blue-text post-item">
                                   <i data-position="top" class="tiny material-icons">mode_error</i>
                               </a>
                               <?php } } if($user->permission()->id == 1){?>
                               <a href="javascript:;" data-post-id="<?php echo $fetch->post_id;?>" data-post-action="trash" class="blue-text post-item">
                                   <i data-position="top" class="tiny material-icons">mode_delete</i>
                               </a>
                               <?php }?>
                                <?php if($user->permission()->id == 3){ if($fetch->status==1){ ?>
                                    <span class="right green text-white" style="color:#FFF;">Approved</span>
                                <?php }else{?><span class="right red" style="color:#FFF;">Pending</span>
                               <?php }}?>
                          </div>                        
                    </div> 
                </div>
            <?php }?>
            <div class="clearfix"></div>
            <ul class="pagination">              
            <?php
                //fetch all the data from database.
                $rows=$queryF->num_rows;
                //calculate total page number for the given table in the database 
                $total=ceil($rows/$limit);?>
                <ul class='page'>
                <?php if($id>1)
                {
                        //Go to previous page to show previous 10 items. If its in page 1 then it is inactive
                        echo '<li><a href="?id='.($id-1).'"><i class="material-icons">chevron_left</i></a></li>';
                }else{
                        echo '<li class="disabled"><a href="javascript:;"><i class="material-icons">chevron_left</i></a></li>';
                }
                
                ?>

                <?php
                for($i=1;$i<=$total;$i++)
                {
                        if($i==$id) { echo "<li class='active'>".$i."</li>"; }

                        else { echo '<li class="waves-effect"><a href="?id='.$i.'">'.$i.'</a></li>'; }
                }
                if($id!=$total)
                {
                        ////Go to previous page to show next 10 items.
                        echo '<li class="waves-effect"><a href="?id='.($id+1).'"><i class="material-icons">chevron_right</i></a></li>';
                }else{
                        echo '<li class="disabled"><a href="javascript:;"><i class="material-icons">chevron_right</i></a></li>';
                }
                ?>
            </ul>
            <?php }else{ ?>
            <h5 align="center">No Blog Posts Found</h5>
            <p align="center"><a href="./" class="btn btn-gray btn-small">Create New Post</a></p>
            <?php }?>
              </div>
        </div>
        
        
    </div>
</div>
<span id="op"></span>
<script>
$(document).ready(function(){
    $(".post-item").click(function(e){ var this_ = $(this);
       var post_action = this_.attr('data-post-action');
       var status = this_.children('i').html();
       var post_id = this_.attr('data-post-id');
       if(status == 'mode_error'){
           this_.children('i').html('mode_done');
           this_.attr('data-post-action','unpublish');
       }else if(status == 'mode_done'){
           this_.children('i').html('mode_error');
           this_.attr('data-post-action','publish');
       }else if(status == 'mode_delete'){
           // delete remove attr
           if(confirm("Are you sure want to delete?")){
                this_.closest(".post-item-head").remove();
                var elementLength = $('.post-item-head').length;
                if(elementLength == 0){
                    document.location.href=''; 
                }
            }else{
                return false;
            }
       }
       
       var post_url= 'ajax_post.php';
       var myData  = {post_id:post_id,action:post_action};
       $.ajax({
            url: post_url,
            type: 'POST',
            data:  myData,
            dataType: "text",
            success: function(data, textStatus, jqXHR)
            {
                    //alert(data);
                    $('#op').html(data);
            },
            error: function(jqXHR, textStatus, errorThrown) 
            {
                    alert(textStatus);
            }           
       });
       
    });
});

</script>       

<?php include('footer.php'); ?>


        